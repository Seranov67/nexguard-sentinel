# NexGuard Sentinel — актуальний план 3–13 вересня 2026

> Перебудовано після повного аудиту 3 вересня. Усі години — Europe/Kyiv.
> Детальні ризики та критерії: [`AUDIT-2026-09-03.md`](AUDIT-2026-09-03.md).

## Рішення, які більше не переглядаємо

1. Єдиний sponsor target — **The Graph AI/Continuity**.
2. 0G видалено зі scope; Chainlink Automation не використовується.
3. Submission зберігає Git-історію `nexguard-edge-resilience`; останній pre-event
   commit позначається baseline tag. Нова feature area пишеться після старту.
4. Автоматизація має право тільки pause. Unpause — owner/human only.
5. The Graph і structured AI classification — load-bearing, але остання authority
   перед транзакцією завжди deterministic `ActionPolicy`.
6. Durable reservation/reconciliation, dedupe і post-action verification не
   скорочуються за жодних умов.

## Фаза 0 — до старту

### Чт 3 вересня, вечір

- [x] Повний аудит і нова sponsor strategy
- [x] Синхронізувати docs, disclosure, spec, YAML і checklist
- [x] Виправити write-path spike semantics
- [x] Підняти Python 3.11 venv і встановити pinned dependencies
- [ ] Deploy Pausable у Base Sepolia
- [ ] Pause / unpause / already-desired / timeout branch
- [ ] Заповнити `spikes/writepath/FINDINGS.md`
- [x] Зробити local recoverable backup і перевірити restore/hash
- [ ] Скопіювати backup off-device і повторно перевірити hash

### Пт 4 вересня, до 17:00

- [x] Встановити локальний pinned Graph CLI
- [ ] Deploy мінімальний `pausable-spike` у Subgraph Studio
- [ ] `query.py` повертає live `PausedSet`
- [ ] Записати sync/query/event latency
- [ ] Остаточний GO/NO-GO для The Graph як hot source
- [ ] Перевірити окремий testnet-only wallet і faucet balance

**Gate 0:** write-path підтверджений; live Graph query повертає подію; toolchain
відтворюється. Без цього не починати продуктову реалізацію навмання.

## Хакатон

### Пт 4 вересня — після Dashboard-confirmed start (planning: 19:00–22:00)

- спочатку записати підтверджений start timestamp у compliance register;
- створити event feature branch із повною попередньою історією;
- tag останнього pre-event commit як `pre-ethonline-2026`;
- додати disclosure, AI usage/prompt logs, architecture spec і threat model;
- створити Python 3.11 package, lock, ruff, mypy strict, pytest і CI;
- комітити завершеними slices, не штучною нарізкою документів.

**Gate 1:** fresh checkout запускає lint/type/test; baseline diff однозначний.

### Сб 5 вересня — contracts + live data (8 год)

- Guardian: keeper pause-only, owner-only unpause, incident ref у події;
- Vault/Simulator реально читає `guardian.paused()`;
- contract unit tests;
- deploy Guardian першим, Vault другим;
- Subgraph entity ID = transaction hash + log index;
- live Python query повертає Withdrawal.

**Gate 2:** event видно через Graph; manual pause блокує повторну Vault operation.

### Нд 6 вересня — мінімальний end-to-end loop (8 год)

- durable cursor, ascending pagination, dedupe, confirmation rewind;
- `Signal`, threshold detector, incident lifecycle;
- durable `check_and_reserve → persist tx hash → finalise/reconcile`;
- pre-read, send, confirmations, state re-read;
- happy path без Telegram і UI.

**Gate 3 о 22:00:** live Graph event автоматично дає verified pause; duplicate
delivery не створює другу tx.

### Пн 7 вересня — failure semantics і check-in (2–3 год)

- restart після reserve/send;
- reconcile за tx hash/nonce;
- outcomes: confirmed success/revert, already desired, indeterminate;
- idempotent audit ref;
- Telegram task registry/outbox;
- Dashboard check-in із working vertical slice.

### Вт 8 вересня — The Graph AI qualification (2–3 год)

- structured classifier над Graph-derived features;
- schema validation, deterministic settings, timeout, fail-closed;
- low confidence/invalid output не дозволяє action;
- feedback session: показати prize fit і safety boundary.

### Ср 9 вересня — hardening (2–3 год)

- unit tests: policy, cursor, classifier, canonical hash;
- contract access-control/idempotency tests;
- fake Graph + fake RPC integration test;
- concurrency test: одна entity одночасно → одна reservation/tx;
- Base Sepolia smoke.

### Чт 10 вересня — feature freeze і check-in (2–3 год)

- усі must-have acceptance criteria зелені;
- виправляти лише P0/P1;
- schema, CLI і demo flow заморожені;
- другий sponsor slot лишається порожнім, якщо вже немає готової інтеграції.

### Пт 11 вересня — reliability rehearsal (2 год)

- fresh-clone runbook;
- три повні demo runs;
- degraded paths + manual reset SOP;
- жодних нових features.

### Сб 12 вересня — submission package (8 год)

- README, architecture, safety invariants, baseline diff, quickstart;
- deployed addresses, Graph ID/endpoint, limitations;
- AI usage і disclosure;
- secret/history/denylist scans;
- відео 2–4 хв, ≥720p, без speed-up/TTS;
- перевірка fresh clone на чистому профілі.

### Нд 13 вересня — buffer (4 год)

- форма заповнена до 17:00;
- The Graph Continuity prize обрано й описано точно;
- public repo/video/links/history/baseline tag перевірені;
- 17:00–19:00 — тільки upload contingency; official hard deadline 19:00 Kyiv.

## Must have

- live Graph source;
- cursor/dedupe/reorg-safe rewind;
- deterministic trigger + structured AI classification;
- durable action reservation/reconciliation;
- automatic pause-only;
- confirmations + state re-read;
- atomic/idempotent audit ref;
- tests, disclosure, README і video.

## Порядок скорочення

1. Другий/третій sponsor.
2. Dashboard/frontend.
3. Multi-protocol generalization.
4. Fancy LLM explanation/UI.
5. Окрема proof transaction, якщо ref уже є в atomic pause event.

Не скорочувати durable reservation, dedupe, chain ID guard, verification або
access control.
