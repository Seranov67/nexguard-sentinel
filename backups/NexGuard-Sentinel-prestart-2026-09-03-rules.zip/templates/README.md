# Підготовчі шаблони

Ці файли задають інтерфейси до старту. Після старту їх адаптуємо у feature
branch існуючого `nexguard-edge-resilience`, зберігаючи повну Git-історію та
чітко позначений pre-event baseline.

| Файл | Куди йде | Коли |
|---|---|---|
| [`sentinel.yaml`](sentinel.yaml) | приклад публічного config contract | після Dashboard-confirmed start |
| [`env.template`](env.template) | `.env.template` без секретів | після Dashboard-confirmed start |

---

## `sentinel.yaml` — не просто конфіг

Це головна ілюстрація README і відповідь судді на питання «а як це підключити
до мого протоколу?». Usability — єдина червона зона у власній оцінці проекту,
і цей файл закриває її дешевше за будь-що інше.

Тому він написаний **до коду**, а не виведений з коду. Спочатку описуємо, як
це має виглядати збоку, потім реалізуємо.

Стан на 3 вересня: GraphQL-запит, cursor/dedupe/rewind semantics, structured AI
вихід, durable reservation, verification та outbox уже описані. Це design
contract, а не твердження про готову реалізацію.
