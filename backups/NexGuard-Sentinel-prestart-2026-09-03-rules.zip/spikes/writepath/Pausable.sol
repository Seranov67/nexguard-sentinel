// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title Pausable — мінімальний стенд для спайку write-path.
/// @notice Це НЕ GuardianRegistry. Це найдурніший контракт, на якому можна
///         відпрацювати відправку транзакції з Python: один прапорець,
///         один guard, одна подія, один revert.
///         Спайк викидний — жоден рядок звідси не копіюється в сабміт.
contract Pausable {
    address public guardian;
    bool public paused;
    uint256 public pausedAt;

    event PausedSet(bool indexed value, address indexed by, uint256 at);
    event GuardianChanged(address indexed from, address indexed to);

    error NotGuardian();
    error NoChange();
    error ZeroAddress();

    constructor() {
        guardian = msg.sender;
    }

    modifier onlyGuardian() {
        if (msg.sender != guardian) revert NotGuardian();
        _;
    }

    /// @notice Другий виклик із тим самим значенням реверти́ть — це навмисно.
    ///         Дає готовий сценарій, щоб побачити, як виглядає custom error
    ///         у web3.py і як прочитати його селектор.
    function setPaused(bool value) external onlyGuardian {
        if (paused == value) revert NoChange();
        paused = value;
        pausedAt = block.timestamp;
        emit PausedSet(value, msg.sender, block.timestamp);
    }

    function setGuardian(address next) external onlyGuardian {
        if (next == address(0)) revert ZeroAddress();
        emit GuardianChanged(guardian, next);
        guardian = next;
    }
}
