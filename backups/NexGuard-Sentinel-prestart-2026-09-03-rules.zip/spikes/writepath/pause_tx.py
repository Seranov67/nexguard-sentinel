"""Exercise a guarded Base Sepolia write and verify the resulting state.

This is throwaway pre-event learning code. It deliberately models the outcome
semantics the product must preserve: already desired, confirmed success,
confirmed revert, and indeterminate.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import time
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from eth_account import Account
from web3 import Web3
from web3.exceptions import ContractLogicError, TimeExhausted, TransactionNotFound

HERE = Path(__file__).parent
EXPECTED_CHAIN_ID = 84532


def positive_int(value: str) -> int:
    parsed = int(value)
    if parsed < 1:
        raise argparse.ArgumentTypeError("значення має бути додатним цілим")
    return parsed


def positive_float(value: str) -> float:
    parsed = float(value)
    if parsed <= 0:
        raise argparse.ArgumentTypeError("значення має бути > 0")
    return parsed


def error_selectors(abi: list[dict[str, Any]]) -> dict[str, str]:
    """Return custom-error selector to signature mappings from an ABI."""

    out: dict[str, str] = {}
    for item in abi:
        if item.get("type") != "error":
            continue
        inputs = item.get("inputs", [])
        args = ",".join(str(argument["type"]) for argument in inputs)
        signature = f"{item['name']}({args})"
        selector = Web3.to_hex(Web3.keccak(text=signature)[:4])
        out[selector.lower()] = signature
    return out


def explain_revert(exc: Exception, selectors: dict[str, str]) -> str:
    """Decode a selector whether the provider puts it in data or message text."""

    candidates = (getattr(exc, "data", None), str(exc))
    for candidate in candidates:
        match = re.search(r"0x[0-9a-fA-F]{8}", str(candidate))
        if match is None:
            continue
        selector = match.group(0).lower()
        signature = selectors.get(selector)
        if signature is not None:
            return f"{signature}  (selector {selector})"
        return f"невідомий custom error, selector {selector}"
    return str(exc)


def require_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise SystemExit(f"немає {name} — заповни .env")
    return value


def wait_for_confirmations(
    w3: Web3,
    receipt: Any,
    *,
    confirmations: int,
    timeout: int,
) -> None:
    target_block = int(receipt["blockNumber"]) + confirmations - 1
    deadline = time.monotonic() + timeout
    while w3.eth.block_number < target_block:
        if time.monotonic() >= deadline:
            raise TimeExhausted(
                f"confirmation timeout: current={w3.eth.block_number}, target={target_block}"
            )
        time.sleep(1)


def main() -> None:
    parser = argparse.ArgumentParser(description="setPaused on the spike contract")
    parser.add_argument("value", choices=["true", "false"])
    parser.add_argument("--dry-run", action="store_true", help="тільки estimate_gas")
    parser.add_argument(
        "--force-estimate",
        action="store_true",
        help="навмисно estimate вже досягнутого стану, щоб декодувати NoChange()",
    )
    parser.add_argument("--nonce", type=int, default=None, help="nonce для явної заміни")
    parser.add_argument("--fee-multiplier", type=positive_float, default=2.0)
    parser.add_argument("--timeout", type=positive_int, default=120)
    parser.add_argument("--confirmations", type=positive_int, default=2)
    args = parser.parse_args()
    target = args.value == "true"

    load_dotenv(HERE / ".env")
    deployed_path = HERE / "deployed.json"
    if not deployed_path.exists():
        raise SystemExit("немає deployed.json — спочатку запусти deploy.py")
    deployed = json.loads(deployed_path.read_text(encoding="utf-8"))

    account = Account.from_key(require_env("DEPLOYER_PRIVATE_KEY"))
    w3 = Web3(Web3.HTTPProvider(require_env("RPC_HTTP")))
    if not w3.is_connected():
        raise SystemExit("RPC не відповідає — перевір RPC_HTTP у .env")
    chain_id = w3.eth.chain_id
    if chain_id != EXPECTED_CHAIN_ID:
        raise SystemExit(
            f"chain_id={chain_id}, очікується {EXPECTED_CHAIN_ID} (base-sepolia); write заборонено"
        )

    contract = w3.eth.contract(address=deployed["address"], abi=deployed["abi"])
    selectors = error_selectors(deployed["abi"])
    current = bool(contract.functions.paused().call())
    guardian = str(contract.functions.guardian().call())
    if guardian.lower() != account.address.lower():
        raise SystemExit(
            f"sender {account.address} не є guardian {guardian}; транзакція не відправлена"
        )

    print(f"chain    = {chain_id} (base-sepolia)")
    print(f"contract = {deployed['address']}")
    print(f"guardian = {guardian}")
    print(f"sender   = {account.address}")
    print(f"paused   = {current}  →  {target}")

    if current == target and not args.force_estimate:
        print(
            "\nalready_in_desired_state: транзакція не потрібна і не буде відправлена.\n"
            "Для навчального декодування NoChange() додай --force-estimate."
        )
        return

    try:
        gas = contract.functions.setPaused(target).estimate_gas({"from": account.address})
    except (ContractLogicError, ValueError) as exc:
        print(f"\nREVERT на estimate_gas: {explain_revert(exc, selectors)}")
        print("Транзакція не відправлена, газ не витрачено.")
        if current == target and args.force_estimate:
            print("Очікуваний already-desired/NoChange навчальний сценарій.")
            return
        raise SystemExit(1) from exc

    base_fee = int(w3.eth.get_block("latest")["baseFeePerGas"])
    priority = int(w3.eth.max_priority_fee)
    max_fee = int(base_fee * args.fee_multiplier) + priority
    nonce = (
        args.nonce
        if args.nonce is not None
        else w3.eth.get_transaction_count(account.address, "pending")
    )

    print(f"\ngas est  = {gas}")
    print(f"base_fee = {w3.from_wei(base_fee, 'gwei'):.4f} gwei")
    print(f"priority = {w3.from_wei(priority, 'gwei'):.4f} gwei")
    print(f"max_fee  = {w3.from_wei(max_fee, 'gwei'):.4f} gwei")
    print(f"nonce    = {nonce}{'  (explicit replacement)' if args.nonce is not None else ''}")

    if args.nonce is not None:
        print("УВАГА: replacement fee треба порівняти з original tx, не лише з current base fee.")

    if args.dry_run:
        print("\n--dry-run: нічого не відправлено")
        return

    tx = contract.functions.setPaused(target).build_transaction(
        {
            "from": account.address,
            "nonce": nonce,
            "chainId": chain_id,
            "gas": int(gas * 1.2),
            "maxPriorityFeePerGas": priority,
            "maxFeePerGas": max_fee,
        }
    )
    signed = account.sign_transaction(tx)

    started = time.monotonic()
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    tx_hex = Web3.to_hex(tx_hash)
    print(f"\ntx = {tx_hex}")
    print(f"   https://sepolia.basescan.org/tx/{tx_hex}")
    print("чекаю receipt ...")

    try:
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=args.timeout)
    except TimeExhausted as exc:
        try:
            receipt = w3.eth.get_transaction_receipt(tx_hash)
            print("Receipt з'явився одразу після timeout; продовжую перевірку.")
        except TransactionNotFound:
            print(
                f"\nТАЙМАУТ {args.timeout} c. Outcome indeterminate: tx може бути pending, "
                "dropped, щойно включена або невидима цьому RPC.\n"
                f"tx={tx_hex}, nonce={nonce}, maxFeePerGas={max_fee}.\n"
                "Не повторюй дію автоматично. Спочатку звір receipt, tx і nonce; "
                "replacement використовує той самий nonce та fee вище original."
            )
            raise SystemExit(2) from exc

    elapsed = time.monotonic() - started
    print(f"\nstatus   = {receipt['status']}")
    print(f"block    = {receipt['blockNumber']}")
    print(f"gas used = {receipt['gasUsed']} з {tx['gas']} виділених")
    print(f"час send → receipt = {elapsed:.1f} c   ← ЗАПИСАТИ У FINDINGS.md")

    if int(receipt["status"]) != 1:
        final = bool(contract.functions.paused().call())
        print(f"confirmed_revert: receipt status=0; paused() = {final}")
        raise SystemExit(4)

    try:
        wait_for_confirmations(
            w3,
            receipt,
            confirmations=args.confirmations,
            timeout=args.timeout,
        )
    except TimeExhausted as exc:
        print(f"{exc} → indeterminate; автоматичний retry заборонений")
        raise SystemExit(2) from exc
    print(f"confirmations = {args.confirmations}")

    for log in contract.events.PausedSet().process_receipt(receipt):
        print(f"подія    = PausedSet(value={log['args']['value']}, by={log['args']['by']})")

    final = bool(contract.functions.paused().call())
    print(f"перечитано paused() = {final}")
    if final != target:
        print("РОЗБІЖНІСТЬ: стан не збігається з наміром → indeterminate, latch")
        raise SystemExit(3)
    print("confirmed_success: стан верифіковано")


if __name__ == "__main__":
    main()
