"""Compile Pausable.sol and deploy it to Base Sepolia.

Спайк write-path, крок 1.

Мета не «щоб запустилось», а щоб після цього скрипта ти знав, звідки береться
кожне поле транзакції. 8 вересня на це не буде часу.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

import solcx
from dotenv import load_dotenv
from eth_account import Account
from solcx.install import get_executable
from web3 import Web3
from web3.exceptions import TimeExhausted

HERE = Path(__file__).parent
SOLC_VERSION = "0.8.24"
EXPECTED_CHAIN_ID = 84532
SOLCX_DIR = HERE / ".solcx"


def require_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise SystemExit(f"немає {name} — заповни .env")
    return value


def compile_pausable() -> tuple[list[dict[str, object]], str]:
    """Компіляція через py-solc-x — щоб не тягнути Hardhat заради 40 рядків."""
    installed = {
        str(v) for v in solcx.get_installed_solc_versions(solcx_binary_path=SOLCX_DIR)
    }
    if SOLC_VERSION not in installed:
        print(f"→ встановлюю solc {SOLC_VERSION} (перший раз, ~30 c)")
        solcx.install_solc(SOLC_VERSION, solcx_binary_path=SOLCX_DIR)

    compiled = solcx.compile_files(
        [str(HERE / "Pausable.sol")],
        output_values=["abi", "bin"],
        solc_binary=get_executable(SOLC_VERSION, solcx_binary_path=SOLCX_DIR),
    )
    key = next(k for k in compiled if k.endswith(":Pausable"))
    return compiled[key]["abi"], compiled[key]["bin"]


def main() -> None:
    load_dotenv(HERE / ".env")

    rpc = require_env("RPC_HTTP")
    account = Account.from_key(require_env("DEPLOYER_PRIVATE_KEY"))
    w3 = Web3(Web3.HTTPProvider(rpc))

    if not w3.is_connected():
        raise SystemExit("RPC не відповідає — перевір RPC_HTTP у .env")

    chain_id = w3.eth.chain_id
    balance = w3.eth.get_balance(account.address)
    if chain_id != EXPECTED_CHAIN_ID:
        raise SystemExit(
            f"chain_id={chain_id}, очікується {EXPECTED_CHAIN_ID} (base-sepolia); деплой заборонено"
        )

    print(f"chain_id = {chain_id} (base-sepolia)")
    print(f"deployer = {account.address}")
    print(f"balance  = {w3.from_wei(balance, 'ether')} ETH")

    if balance == 0:
        raise SystemExit("баланс 0 — візьми тестовий ETH на ethglobal.com/faucet")

    abi, bytecode = compile_pausable()
    contract = w3.eth.contract(abi=abi, bytecode=bytecode)

    # ── nonce ────────────────────────────────────────────────────────────
    # "pending", а не "latest": якщо попередня транзакція ще висить у мемпулі,
    # "latest" віддасть старе число, нова транзакція піде з тим самим nonce
    # і замінить попередню. Саме так губляться транзакції в контурі, який
    # шле кілька дій підряд.
    nonce = w3.eth.get_transaction_count(account.address, "pending")

    # ── EIP-1559 ─────────────────────────────────────────────────────────
    # maxPriorityFeePerGas — чайові валідатору, беруться з ноди.
    # maxFeePerGas — стеля, яку ти готовий заплатити. base fee може зрости
    # за наступні блоки, тому запас x2: інакше транзакція просто зависне.
    # Реально списується base_fee + priority, решта повертається.
    base_fee = w3.eth.get_block("latest")["baseFeePerGas"]
    priority = w3.eth.max_priority_fee
    max_fee = base_fee * 2 + priority

    print(f"base_fee = {w3.from_wei(base_fee, 'gwei'):.4f} gwei")
    print(f"priority = {w3.from_wei(priority, 'gwei'):.4f} gwei")
    print(f"max_fee  = {w3.from_wei(max_fee, 'gwei'):.4f} gwei")

    gas = contract.constructor().estimate_gas({"from": account.address})
    tx = contract.constructor().build_transaction(
        {
            "from": account.address,
            "nonce": nonce,
            "chainId": chain_id,
            "gas": int(gas * 1.2),  # запас: estimate_gas рахує по поточному стану
            "maxPriorityFeePerGas": priority,
            "maxFeePerGas": max_fee,
        }
    )

    signed = account.sign_transaction(tx)
    started = time.monotonic()
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    # Web3.to_hex, а не tx_hash.hex(): у hexbytes 1.x .hex() віддає рядок
    # без префікса 0x, у 0.x — з префіксом. to_hex поводиться однаково.
    print(f"\ndeploy tx = {Web3.to_hex(tx_hash)}")
    print("чекаю receipt ...")

    try:
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)
    except TimeExhausted as exc:
        print(
            "Deployment outcome indeterminate. Не запускай deploy повторно, доки "
            f"не звіриш tx {Web3.to_hex(tx_hash)} і nonce {nonce}."
        )
        raise SystemExit(2) from exc
    elapsed = time.monotonic() - started

    if receipt["status"] != 1:
        raise SystemExit(f"деплой не пройшов, status=0: {receipt}")

    address = receipt["contractAddress"]
    print(f"\ncontract  = {address}")
    print(f"gas used  = {receipt['gasUsed']}")
    print(f"час до receipt = {elapsed:.1f} c   ← ЗАПИСАТИ У FINDINGS.md")
    print(f"basescan  = https://sepolia.basescan.org/address/{address}")

    (HERE / "deployed.json").write_text(
        json.dumps({"address": address, "abi": abi}, indent=2),
        encoding="utf-8",
    )
    print("\n→ deployed.json записано. Далі:  python pause_tx.py true")


if __name__ == "__main__":
    main()
