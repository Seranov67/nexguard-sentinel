# Портування existing resilience core

> Мета — розширити існуючий `nexguard-edge-resilience`, а не створювати новий
> репозиторій без історії. Будь-який reused код має attribution і baseline diff.

## Що переносимо

| Джерело | Ціль | Правило адаптації |
|---|---|---|
| `recovery.py` guards | `sentinel/core/policy.py` | cooldown/window/latch; ніколи не дає unpause |
| incident state machine | `sentinel/core/incident.py` | без import-time Prometheus globals; canonical IDs |
| action/verification pattern | `sentinel/core/executor.py` | reserve → persist tx hash → receipt → confirmations → state re-read |
| `latch-agent` semantics | policy/reconciliation tests | durable latch і operator-attributed human reset |
| `llm-log-monitor` patterns | `sentinel/detect/ai.py` | schema-validated output; AI ніколи не є authority |

Не переносимо filesystem restore, Docker manager, gateway config checker або
FastAPI-обгортку: вони доменно специфічні й не допомагають on-chain loop.

## Інваріанти, які не можна втратити

1. Keeper може лише `pause`; `unpause` — owner/human only із reason hash.
2. Один canonical Graph event ID резервує не більше однієї дії.
3. Після broadcast tx hash зберігається до очікування receipt.
4. Timeout означає `indeterminate` і запускає reconciliation, а не повторний send.
5. Success існує лише після receipt success, confirmations і state re-read.
6. Invalid/low-confidence AI output → refuse and notify.
7. Notification використовує durable outbox або tracked task registry; винятки
   не ковтаються непомітно.

## Цільова структура

    sentinel/
    ├── core/
    │   ├── ATTRIBUTION.md
    │   ├── models.py
    │   ├── incident.py
    │   ├── policy.py
    │   ├── reservation.py
    │   ├── executor.py
    │   └── notifier.py
    ├── sources/subgraph.py
    ├── chain/guardian.py
    ├── detect/thresholds.py
    ├── detect/ai.py
    └── config.py

## Порядок реалізації після старту

1. Позначити останній pre-event commit tag `pre-ethonline-2026`.
2. Додати `ATTRIBUTION.md` із точними source paths і ліцензіями.
3. Портувати лише pure state/policy моделі та спочатку закрити їх тестами.
4. Додати durable reservation/reconciliation до chain executor.
5. Під'єднати Graph source, потім AI classifier, останнім — notifier.
6. У README показати baseline diff: reused, modified і event-written files.

## Мінімальний attribution text

    The resilience state-machine and guard concepts are adapted from the existing
    nexguard-edge-resilience project and disclosed as pre-event work. On-chain
    contracts, The Graph integration, canonical event handling, durable transaction
    reconciliation, and structured AI classification are implemented in the
    ETHOnline 2026 feature area after the tagged baseline.
