# ETHOnline 2026 — партнерська стратегія

> Перевірено 3 вересня 2026 за актуальною сторінкою
> <https://ethglobal.com/events/ethonline2026/prizes>.

## Рішення

**Єдиний партнерський пріоритет — The Graph, трек `Best AI Tooling or AI Use
Case with The Graph (Continuity)`, пул $5,000.**

Prize breakdown shown on 3 September: $2,500 first, $1,500 second, $1,000 third.
The Graph counts as one partner selection; choose the Continuity pool that matches
the existing-project lineage, not the From Scratch pool.

Другий і третій partner slots залишаються порожніми, доки повний контур
`Graph event → classify → policy → pause → verify` не працює end-to-end.

## Що змінилось проти плану 1 вересня

| Було | Факт 3 вересня | Дія |
|---|---|---|
| 0G — кандидат на слот 2 | 0G немає серед партнерів ETHOnline 2026 | Видалити зі scope; spike закрито як obsolete |
| Chainlink Automation — резерв | Chainlink просить CRE; Functions/Automation депрекейтяться | Не інтегрувати Automation |
| Будь-який власний Subgraph підходить The Graph | Одиночний Subgraph без composition/standardization не підходить до composable track | Не подаватись у composable track |
| LLM-класифікація опційна | AI має робити meaningful work для AI prize | Structured classifier входить у must-have |

## The Graph AI/Continuity — qualification map

| Вимога | Реалізація Sentinel | Доказ у submission |
|---|---|---|
| The Graph — load-bearing source | Live Subgraph індексує Vault events; Sentinel не використовує mock/local dataset | Subgraph ID/Studio URL, query, demo |
| Meaningful work with data | Features події перетворюються на structured incident classification | JSON output + decision log |
| Reasoning/decision/automation | Classification входить у incident severity; deterministic policy вирішує, чи дозволена дія | End-to-end trace |
| Public source | Репозиторій публічний і має runnable README | Anonymous-access test + GitHub URL |
| 2–4 minute video | Live event → pause → verify | Відео 3:30 |
| Continuity disclosure | Baseline commit/tag + таблиця prior/new | README + `DISCLOSURE.md` + event changelog |

## Safety boundary для AI

AI не має прямого доступу до signer і не може обійти policy. Його вихід:

```json
{
  "severity": "critical",
  "rationale": "three high-value withdrawals in a short window",
  "recommended_action": "pause",
  "confidence": 0.93
}
```

проходить schema validation і deterministic guards. Timeout, invalid JSON,
невідома severity або низька confidence → `refuse + notify`, а не action.
Hard safety threshold може pause незалежно від LLM, але це має бути явно
позначено в trace як deterministic override.

Якщо демонстрація показує лише deterministic threshold, а AI output не впливає
на reasoning/decision/automation, вимога AI track не доведена. Submission trace
має окремо показати Graph-derived AI input, validated output і вплив на рішення.

## Інші партнери

| Партнер | Рішення | Причина |
|---|---|---|
| Chainlink | Не брати до feature freeze | CRE/TEE — окремий стек і не потрібен ядру |
| Ledger | Не брати до feature freeze | Хороший fit для signer, але потребує Agent Stack/Key Ring і окремого demo |
| Bazantic | Не брати | Gateway/Recipe та comparison video розпорошують scope |
| Hedera / Arc / World / ENS / 1inch / Uniswap / Privy | Не брати | Не є load-bearing для поточної архітектури |

## Gate

The Graph залишається ціллю лише якщо до **4 вересня 17:00 Kyiv** мінімальний
live Studio Subgraph повертає реальну Base Sepolia подію з Python-клієнта.
Результат і latency записуються в `spikes/thegraph/FINDINGS.md`.
