# Optional ETHGlobal support ticket

> Стан 3 вересня: **не є блокером**. Актуальна prize page вже має окремий
> The Graph AI/Continuity pool і правила дозволяють existing open-source repo.
> Тікет потрібен лише якщо Dashboard не дозволяє обрати цей pool або лишається
> сумнів щодо repository lineage.

## Draft

```text
Hi! I plan to submit to the ETHOnline 2026 Continuity Track with a new on-chain
incident-response feature built on this existing MIT repository:
https://github.com/Seranov67/nexguard-edge-resilience

The repository was public before the event. I will preserve its full history,
tag the final pre-event commit, and clearly document all prior work. The new
event-period work will include a live The Graph data source, structured AI
incident classification, guarded on-chain pause execution, verification, and
contracts.

The prize page lists "Best AI Tooling or AI Use Case with The Graph
(Continuity)". Can you confirm that I should keep the existing repository
history and select that Continuity pool in the submission form?

For completeness: the prior repository was prepared as a DoraHacks MVP in July
but its BUIDL was never published or submitted. A second pre-event project,
https://github.com/Seranov67/latch-agent, informs the durable action-policy
design but its TypeScript implementation will not be presented as new work.

Thank you!
```

## Log

| Date/time Kyiv | Channel | Result |
|---|---|---|
| — | — | Not sent |
