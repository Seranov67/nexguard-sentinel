# Демо-відео — сценарій

> Ціль: 3:30. Остаточні вимоги звірити з submission form перед записом.

## Official format gate

- duration: 2–4 minutes; upload rejects shorter/longer videos;
- resolution: at least 720p;
- no speed-up;
- no mobile-phone recording;
- no text-to-speech or AI voiceover; use clear human narration;
- editing out unnecessary waiting is explicitly allowed.

Source: <https://ethglobal.com/events/ethonline2026/info/details>.

## Розкадровка

| Час | Екран | Ключова теза англійською |
|---|---|---|
| 0:00–0:20 | Проблема: аномальна серія withdrawal | Detection without a safe response loop still leaves a sleeping human in the critical path. |
| 0:20–0:40 | Архітектура | The Graph supplies indexed protocol data; deterministic policy remains the final authority. |
| 0:40–2:15 | Живий end-to-end сценарій | Показувати факти й переходи стану, не слайди. |
| 2:15–2:45 | Policy + durable reservation | One canonical event can reserve at most one action, including after restart. |
| 2:45–3:10 | Existing Git history + baseline diff | Existing resilience primitives are disclosed; the on-chain extension is isolated by the pre-event baseline. |
| 3:10–3:30 | Config, Graph ID, contract address | The Graph is load-bearing for detection and AI-derived features, while automation is pause-only. |

## Центральні 95 секунд

| Момент | Що має бути видно |
|---|---|
| 0:40 | Sentinel стартує; chain ID, Graph head і cursor показані без секретів. |
| 0:52 | Testnet-скрипт створює серію `Withdrawal`. |
| 1:02 | Graph source повертає canonical entity; deterministic detector відкриває incident. |
| 1:12 | Structured AI classifier повертає валідний label/confidence/reasons. |
| 1:22 | `ActionPolicy` дозволяє pause; durable `check_and_reserve` створює одну reservation. |
| 1:32 | `pause(incidentRef, severity)` відправлено; tx hash записаний негайно. |
| 1:44 | Receipt success + confirmations + `paused() == true`; reservation фіналізована. |
| 1:58 | Повторна доставка тієї самої entity не створює другої транзакції. |
| 2:08 | Нова Vault operation відхиляється, бо guardian paused; outbox надсилає сповіщення. |

Якщо реальна Graph/chain latency не вкладається, ETHGlobal дозволяє вирізати
непотрібне очікування. Внутрішній стандарт прозорості: додати видиму позначку
elapsed time. Не прискорювати відео.

## Обов'язкові negative-path кадри

- malformed або low-confidence AI output → `refuse + notify`, без транзакції;
- duplicate event → existing reservation/result;
- timeout після broadcast → `indeterminate`, не «failed» і не повторний send;
- unpause доступний лише owner/human та має reason hash.

## Перед записом

1. Три повних rehearsal із чистого стартового стану.
2. Перевірити актуальний ліміт, формат, мову й вимоги до відео у submission form.
3. Приховати `.env`, wallet extensions, deploy keys, RPC URLs і сповіщення ОС.
4. Показати реальні Basescan/Graph посилання та baseline diff.
5. Не заявляти production readiness: це Base Sepolia prototype з явними limits.

## Опис під відео — чернетка

    NexGuard Sentinel is a pause-only incident-response loop for on-chain protocols.
    It consumes indexed protocol events through The Graph, derives structured AI
    context, applies deterministic safety policy, reserves one idempotent action,
    pauses a Guardian contract, and verifies the final on-chain state.

    ETHOnline 2026 — The Graph AI/Continuity.
    Prior work and the pre-event baseline are disclosed in the repository.
