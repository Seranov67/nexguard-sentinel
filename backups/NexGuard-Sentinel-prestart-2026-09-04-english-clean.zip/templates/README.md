# Pre-event interface templates

These files define public interfaces before implementation. After the confirmed
hacking start, adapt them on the event branch of `nexguard-edge-resilience` while
preserving full history and pre-event provenance.

| Template | Intended use | Timing |
|---|---|---|
| [`sentinel.yaml`](sentinel.yaml) | Public configuration contract | after Dashboard-confirmed start |
| [`env.template`](env.template) | Secret-free environment example | after Dashboard-confirmed start |

`sentinel.yaml` is a design contract, not evidence of implementation. It already
specifies a declared GraphQL query, durable cursor and deduplication behavior,
confirmation rewind, structured AI output, durable action reservation, final
state verification, and notification outbox. Event code must either implement
these semantics or explicitly update the template and specification together.
