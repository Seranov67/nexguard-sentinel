# The Graph — findings

**Updated:** 3 September 2026  
**Status:** local toolchain verified; live experiment blocked on credentials/deploy

## Local evidence

| Check | Result |
|---|---|
| CLI | `@graphprotocol/graph-cli/0.98.1 win32-x64 node-v22.17.1` |
| Install model | project-local, exact dependency + lockfile |
| Python query | compiles under Python 3.11 |
| Live endpoint | not configured |
| Dependency audit | 15 advisories: 4 moderate, 10 high, 1 critical |

The CLI advisory set cannot currently be removed without npm proposing a breaking
downgrade. It is accepted only for isolated, trusted-input development and remains
an open toolchain risk.

## Main question

> Can the subgraph replace a custom indexer for the hot response path?

**Answer:** not yet measured. Architecture remains intentionally reversible:
Graph-first if p95 event appearance is acceptable; otherwise RPC hot path plus
The Graph for canonical history, analytics and structured AI features.

## Measurements still required

| Measurement | Value |
|---|---|
| deploy → synced head | pending |
| event receipt → Graph entity visible | pending |
| GraphQL response time | pending |
| reorg/rewind behavior observed | pending |

## GO/NO-GO rule

- **GO Graph-only:** repeated event-appearance latency fits the demo and operational
  target, with stable cursor and rewind behavior.
- **GO hybrid:** Graph qualifies and enriches the system but measured hot-path
  latency is too high.
- **NO-GO:** live deployment/query cannot be reproduced by Gate 0.

## Required inputs

1. Disposable Base Sepolia private key funded only with faucet ETH.
2. Base Sepolia HTTPS RPC URL.
3. The Graph Studio project/deploy key and gateway query URL.

No secret values belong in this file.
