"""Query live PauseChange entities and print latency without exposing credentials."""

from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request

QUERY = """
query RecentPauseChanges {
  pauseChanges(first: 10, orderBy: at, orderDirection: desc) {
    id
    value
    by
    at
    blockNumber
    transactionHash
  }
  _meta {
    block { number hash }
  }
}
"""


def main() -> None:
    endpoint = os.getenv("SUBGRAPH_URL")
    if not endpoint:
        raise SystemExit("SUBGRAPH_URL is not set in the environment")

    body = json.dumps({"query": QUERY}).encode("utf-8")
    request = urllib.request.Request(
        endpoint,
        data=body,
        headers={"content-type": "application/json"},
        method="POST",
    )
    started = time.monotonic()
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            payload = json.load(response)
    except (urllib.error.URLError, TimeoutError) as exc:
        raise SystemExit(f"Graph query failed: {type(exc).__name__}") from exc
    elapsed_ms = (time.monotonic() - started) * 1000

    if payload.get("errors"):
        messages = [error.get("message", "unknown GraphQL error") for error in payload["errors"]]
        raise SystemExit("GraphQL errors: " + "; ".join(messages))

    data = payload.get("data") or {}
    changes = data.get("pauseChanges") or []
    meta = data.get("_meta") or {}
    block = (meta.get("block") or {}).get("number")
    print(f"query latency = {elapsed_ms:.0f} ms")
    print(f"indexed block = {block}")
    print(f"pause changes = {len(changes)}")
    for change in changes:
        print(json.dumps(change, sort_keys=True, separators=(",", ":")))


if __name__ == "__main__":
    main()
