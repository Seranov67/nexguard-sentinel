# The Graph spike

The Graph is the only selected ETHOnline 2026 sponsor track. This pre-event spike
tests the toolchain and live latency; its code is not the event implementation.

## Local status — 3 September 2026

- Node `22.17.1`
- local pinned `@graphprotocol/graph-cli` `0.98.1`
- `query.py` passes Python 3.11 syntax compilation
- no global CLI install is required
- live deploy is waiting for a testnet contract, Studio project and deploy key

## Commands

    npm install
    npx graph --version
    npx graph init --studio pausable-spike
    npx graph codegen
    npx graph build
    npx graph deploy pausable-spike

Query an existing deployment without storing its endpoint in source control:

    $env:SUBGRAPH_URL = "https://gateway.thegraph.com/api/<key>/subgraphs/id/<id>"
    ..\writepath\.venv\Scripts\python.exe query.py
    Remove-Item Env:SUBGRAPH_URL

Never print or commit the gateway/deploy key. Use the disposable hackathon wallet,
not a personal or funded wallet.

## Dependency advisory boundary

`npm audit` reports vulnerabilities inside the latest pinned Graph CLI dependency
tree, including `decompress@4.2.1`. `npm audit fix --force` proposes a breaking
downgrade to CLI `0.91.1`; do not apply it. Treat this CLI as an isolated dev tool:

- initialize only from our Base Sepolia contract and local ABI;
- do not extract or process untrusted templates/archives;
- do not run it from privileged directories;
- keep deploy keys ephemeral and out of shell history where practical;
- rerun `npm audit` and review upstream before submission.

## Live definition of done

- [ ] testnet-only Pausable is deployed on Base Sepolia
- [ ] `pausable-spike` is deployed in Subgraph Studio
- [ ] `query.py` returns the corresponding `PausedSet` entity
- [ ] sync, event-appearance and GraphQL response latency are recorded
- [ ] hot-source decision is written in `FINDINGS.md`

The live result decides between Graph-only polling and a hybrid design where RPC
is the hot path and The Graph remains load-bearing for history and AI features.
