# Throwaway preparation spikes

## Rule

Do not copy spike code mechanically into the submission implementation. Reuse
only verified knowledge and semantics, then implement them after the confirmed
hacking start with event-period tests and history.

| Directory | Status | Question |
|---|---|---|
| [`writepath/`](writepath/) | local checks complete; live run pending | Can Python safely submit, classify, and verify a state-changing transaction? |
| [`thegraph/`](thegraph/) | local tooling complete; live deploy pending | Can a live Subgraph support the response path at acceptable latency? |
| [`0g/`](0g/) | archived | Sponsor is absent from the current ETHOnline 2026 prize list. |

A spike is complete only when `FINDINGS.md` contains measured evidence. Working
code without recorded conclusions does not close the gate.

The spike topology mirrors the intended demo: write-path deploys the event source;
The Graph indexes it; the Python client consumes it. If measured Subgraph latency
is unsuitable for the hot path, use an honestly documented hybrid architecture
while keeping The Graph load-bearing for history and AI-derived features.
