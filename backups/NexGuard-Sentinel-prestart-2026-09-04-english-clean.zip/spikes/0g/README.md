# 0G spike — archived

The spike was cancelled on 3 September 2026 because 0G is not listed among the
current ETHOnline 2026 sponsors. No SDK evaluation or integration work should be
scheduled. The decision record is in [`VERDICT.md`](VERDICT.md).
