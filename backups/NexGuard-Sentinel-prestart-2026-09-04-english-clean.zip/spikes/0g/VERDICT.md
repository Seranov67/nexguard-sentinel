# 0G spike — cancelled

**Decision date:** 3 September 2026

0G does not appear among the 11 partners on the current ETHOnline 2026 prize
page. The planned SDK spike would not support an eligible partner submission and
is therefore cancelled before any integration time is spent.

**Verdict:** 0G is not in slot 2. Slot 2 remains empty until the core end-to-end
loop is stable at feature freeze.

Source checked: <https://ethglobal.com/events/ethonline2026/prizes>.
