"""Exercise a guarded Base Sepolia write and verify the resulting state.

This is throwaway pre-event learning code. It deliberately models the outcome
semantics the product must preserve: already desired, confirmed success,
confirmed revert, and indeterminate.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import time
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from eth_account import Account
from web3 import Web3
from web3.exceptions import ContractLogicError, TimeExhausted, TransactionNotFound

HERE = Path(__file__).parent
EXPECTED_CHAIN_ID = 84532


def positive_int(value: str) -> int:
    parsed = int(value)
    if parsed < 1:
        raise argparse.ArgumentTypeError("value must be a positive integer")
    return parsed


def positive_float(value: str) -> float:
    parsed = float(value)
    if parsed <= 0:
        raise argparse.ArgumentTypeError("value must be greater than zero")
    return parsed


def error_selectors(abi: list[dict[str, Any]]) -> dict[str, str]:
    """Return custom-error selector to signature mappings from an ABI."""

    out: dict[str, str] = {}
    for item in abi:
        if item.get("type") != "error":
            continue
        inputs = item.get("inputs", [])
        args = ",".join(str(argument["type"]) for argument in inputs)
        signature = f"{item['name']}({args})"
        selector = Web3.to_hex(Web3.keccak(text=signature)[:4])
        out[selector.lower()] = signature
    return out


def explain_revert(exc: Exception, selectors: dict[str, str]) -> str:
    """Decode a selector whether the provider puts it in data or message text."""

    candidates = (getattr(exc, "data", None), str(exc))
    for candidate in candidates:
        match = re.search(r"0x[0-9a-fA-F]{8}", str(candidate))
        if match is None:
            continue
        selector = match.group(0).lower()
        signature = selectors.get(selector)
        if signature is not None:
            return f"{signature}  (selector {selector})"
        return f"unknown custom error, selector {selector}"
    return str(exc)


def require_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise SystemExit(f"missing {name}; populate .env")
    return value


def wait_for_confirmations(
    w3: Web3,
    receipt: Any,
    *,
    confirmations: int,
    timeout: int,
) -> None:
    target_block = int(receipt["blockNumber"]) + confirmations - 1
    deadline = time.monotonic() + timeout
    while w3.eth.block_number < target_block:
        if time.monotonic() >= deadline:
            raise TimeExhausted(
                f"confirmation timeout: current={w3.eth.block_number}, target={target_block}"
            )
        time.sleep(1)


def main() -> None:
    parser = argparse.ArgumentParser(description="setPaused on the spike contract")
    parser.add_argument("value", choices=["true", "false"])
    parser.add_argument("--dry-run", action="store_true", help="estimate gas only")
    parser.add_argument(
        "--force-estimate",
        action="store_true",
        help="estimate an already reached state to exercise NoChange() decoding",
    )
    parser.add_argument("--nonce", type=int, default=None, help="nonce for explicit replacement")
    parser.add_argument("--fee-multiplier", type=positive_float, default=2.0)
    parser.add_argument("--timeout", type=positive_int, default=120)
    parser.add_argument("--confirmations", type=positive_int, default=2)
    args = parser.parse_args()
    target = args.value == "true"

    load_dotenv(HERE / ".env")
    deployed_path = HERE / "deployed.json"
    if not deployed_path.exists():
        raise SystemExit("deployed.json is missing; run deploy.py first")
    deployed = json.loads(deployed_path.read_text(encoding="utf-8"))

    account = Account.from_key(require_env("DEPLOYER_PRIVATE_KEY"))
    w3 = Web3(Web3.HTTPProvider(require_env("RPC_HTTP")))
    if not w3.is_connected():
        raise SystemExit("RPC is unavailable; check RPC_HTTP in .env")
    chain_id = w3.eth.chain_id
    if chain_id != EXPECTED_CHAIN_ID:
        raise SystemExit(
            f"chain_id={chain_id}; expected {EXPECTED_CHAIN_ID} (base-sepolia); write refused"
        )

    contract = w3.eth.contract(address=deployed["address"], abi=deployed["abi"])
    selectors = error_selectors(deployed["abi"])
    current = bool(contract.functions.paused().call())
    guardian = str(contract.functions.guardian().call())
    if guardian.lower() != account.address.lower():
        raise SystemExit(
            f"sender {account.address} is not guardian {guardian}; transaction not sent"
        )

    print(f"chain    = {chain_id} (base-sepolia)")
    print(f"contract = {deployed['address']}")
    print(f"guardian = {guardian}")
    print(f"sender   = {account.address}")
    print(f"paused   = {current}  →  {target}")

    if current == target and not args.force_estimate:
        print(
            "\nalready_in_desired_state: no transaction is required or sent.\n"
            "Use --force-estimate only to exercise NoChange() decoding."
        )
        return

    try:
        gas = contract.functions.setPaused(target).estimate_gas({"from": account.address})
    except (ContractLogicError, ValueError) as exc:
        print(f"\nestimate_gas reverted: {explain_revert(exc, selectors)}")
        print("No transaction was sent and no gas was spent.")
        if current == target and args.force_estimate:
            print("Expected already-desired/NoChange exercise completed.")
            return
        raise SystemExit(1) from exc

    base_fee = int(w3.eth.get_block("latest")["baseFeePerGas"])
    priority = int(w3.eth.max_priority_fee)
    max_fee = int(base_fee * args.fee_multiplier) + priority
    nonce = (
        args.nonce
        if args.nonce is not None
        else w3.eth.get_transaction_count(account.address, "pending")
    )

    print(f"\ngas est  = {gas}")
    print(f"base_fee = {w3.from_wei(base_fee, 'gwei'):.4f} gwei")
    print(f"priority = {w3.from_wei(priority, 'gwei'):.4f} gwei")
    print(f"max_fee  = {w3.from_wei(max_fee, 'gwei'):.4f} gwei")
    print(f"nonce    = {nonce}{'  (explicit replacement)' if args.nonce is not None else ''}")

    if args.nonce is not None:
        print(
            "WARNING: compare replacement fee with the original transaction, "
            "not only current base fee."
        )

    if args.dry_run:
        print("\n--dry-run: nothing sent")
        return

    tx = contract.functions.setPaused(target).build_transaction(
        {
            "from": account.address,
            "nonce": nonce,
            "chainId": chain_id,
            "gas": int(gas * 1.2),
            "maxPriorityFeePerGas": priority,
            "maxFeePerGas": max_fee,
        }
    )
    signed = account.sign_transaction(tx)

    started = time.monotonic()
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    tx_hex = Web3.to_hex(tx_hash)
    print(f"\ntx = {tx_hex}")
    print(f"   https://sepolia.basescan.org/tx/{tx_hex}")
    print("waiting for receipt ...")

    try:
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=args.timeout)
    except TimeExhausted as exc:
        try:
            receipt = w3.eth.get_transaction_receipt(tx_hash)
            print("Receipt appeared immediately after timeout; continuing verification.")
        except TransactionNotFound:
            print(
                f"\nTIMEOUT after {args.timeout} s. Outcome is indeterminate: the transaction "
                "may be pending, dropped, newly included, or invisible to this RPC.\n"
                f"tx={tx_hex}, nonce={nonce}, maxFeePerGas={max_fee}.\n"
                "Do not retry automatically. Reconcile receipt, transaction, and nonce first; "
                "a replacement uses the same nonce and a fee above the original."
            )
            raise SystemExit(2) from exc

    elapsed = time.monotonic() - started
    print(f"\nstatus   = {receipt['status']}")
    print(f"block    = {receipt['blockNumber']}")
    print(f"gas used = {receipt['gasUsed']} of {tx['gas']} allocated")
    print(f"send to receipt = {elapsed:.1f} s; record in FINDINGS.md")

    if int(receipt["status"]) != 1:
        final = bool(contract.functions.paused().call())
        print(f"confirmed_revert: receipt status=0; paused() = {final}")
        raise SystemExit(4)

    try:
        wait_for_confirmations(
            w3,
            receipt,
            confirmations=args.confirmations,
            timeout=args.timeout,
        )
    except TimeExhausted as exc:
        print(f"{exc} -> indeterminate; automatic retry is forbidden")
        raise SystemExit(2) from exc
    print(f"confirmations = {args.confirmations}")

    for log in contract.events.PausedSet().process_receipt(receipt):
        print(f"event    = PausedSet(value={log['args']['value']}, by={log['args']['by']})")

    final = bool(contract.functions.paused().call())
    print(f"re-read paused() = {final}")
    if final != target:
        print("STATE MISMATCH: final state differs from intent -> indeterminate, latch")
        raise SystemExit(3)
    print("confirmed_success: final state verified")


if __name__ == "__main__":
    main()
