# Write-path — measured findings

**Status:** local toolchain verified; live measurements blocked on testnet credentials.

| Field | Value |
|---|---|
| Date/time Kyiv | 3 September 2026 |
| Python | 3.11.9, isolated `.venv` |
| web3 | 7.16.0 |
| py-solc-x | 2.0.5 |
| solc | 0.8.24 |
| Base Sepolia chain ID | 84532 |
| Contract | — |
| Testnet wallet | record address only after live run |

## Measurements

| Metric | Value |
|---|---|
| Deploy send → receipt | — s |
| setPaused send → receipt | — s |
| Two-confirmation total | — s |
| setPaused gas used | — |
| Base fee | — gwei |
| Effective gas price | — gwei |
| Action cost | — ETH |

## Outcome matrix

| Path | Observed | Evidence |
|---|---|---|
| `confirmed_success` pause | no | — |
| `confirmed_success` unpause | no | — |
| `already_in_desired_state` | no | — |
| forced `NoChange()` decode | no | — |
| timeout → `indeterminate` | no | — |
| wrong-chain refusal | covered locally by code; live negative test optional | — |

## Local verification

- `ruff check .` — pass
- `mypy deploy.py pause_tx.py` — pass under strict configuration
- `pytest` — 6 passed
- Solidity 0.8.24 compilation — pass; ABI has 11 entries, bytecode 1545 bytes

## Decisions for product client

- receipt timeout: choose after live measurement;
- confirmation depth: 2 for demo;
- timeout is indeterminate, never automatic failure/retry;
- persist intent before send and tx hash immediately after send;
- compare replacement fee to stored original transaction;
- pre-read desired state before reservation.

Do not mark this spike complete until the live fields above contain actual values.
