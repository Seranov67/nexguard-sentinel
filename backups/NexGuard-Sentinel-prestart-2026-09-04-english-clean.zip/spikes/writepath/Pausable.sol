// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title Minimal Pausable contract for the write-path spike
/// @notice This is NOT GuardianRegistry. It is a deliberately small contract for
///         exercising Python transaction submission: one flag, one guard, one
///         event, and one revert. This throwaway code is not copied into submission.
contract Pausable {
    address public guardian;
    bool public paused;
    uint256 public pausedAt;

    event PausedSet(bool indexed value, address indexed by, uint256 at);
    event GuardianChanged(address indexed from, address indexed to);

    error NotGuardian();
    error NoChange();
    error ZeroAddress();

    constructor() {
        guardian = msg.sender;
    }

    modifier onlyGuardian() {
        if (msg.sender != guardian) revert NotGuardian();
        _;
    }

    /// @notice Repeating the same value intentionally reverts, providing a stable
    ///         scenario for observing and decoding a custom error in web3.py.
    function setPaused(bool value) external onlyGuardian {
        if (paused == value) revert NoChange();
        paused = value;
        pausedAt = block.timestamp;
        emit PausedSet(value, msg.sender, block.timestamp);
    }

    function setGuardian(address next) external onlyGuardian {
        if (next == address(0)) revert ZeroAddress();
        emit GuardianChanged(guardian, next);
        guardian = next;
    }
}
