from __future__ import annotations

import argparse

import pytest
from web3 import Web3

from pause_tx import error_selectors, explain_revert, positive_float, positive_int


class RevertWithData(Exception):
    def __init__(self, data: str) -> None:
        super().__init__("execution reverted")
        self.data = data


def test_error_selector_decodes_data_field() -> None:
    abi = [{"type": "error", "name": "NoChange", "inputs": []}]
    selectors = error_selectors(abi)
    selector = Web3.to_hex(Web3.keccak(text="NoChange()")[:4])

    assert explain_revert(RevertWithData(selector), selectors) == (
        f"NoChange()  (selector {selector})"
    )


def test_error_selector_decodes_message_fallback() -> None:
    abi = [{"type": "error", "name": "NoChange", "inputs": []}]
    selectors = error_selectors(abi)
    selector = Web3.to_hex(Web3.keccak(text="NoChange()")[:4])

    assert "NoChange()" in explain_revert(Exception(f"rpc error data={selector}"), selectors)


@pytest.mark.parametrize("value", ["0", "-1"])
def test_positive_int_rejects_non_positive(value: str) -> None:
    with pytest.raises(argparse.ArgumentTypeError):
        positive_int(value)


@pytest.mark.parametrize("value", ["0", "-0.1"])
def test_positive_float_rejects_non_positive(value: str) -> None:
    with pytest.raises(argparse.ArgumentTypeError):
        positive_float(value)
