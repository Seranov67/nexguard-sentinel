"""Compile Pausable.sol and deploy it to Base Sepolia.

Write-path spike, step 1.

The goal is to make every transaction field explicit before product work begins.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

import solcx
from dotenv import load_dotenv
from eth_account import Account
from solcx.install import get_executable
from web3 import Web3
from web3.exceptions import TimeExhausted

HERE = Path(__file__).parent
SOLC_VERSION = "0.8.24"
EXPECTED_CHAIN_ID = 84532
SOLCX_DIR = HERE / ".solcx"


def require_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise SystemExit(f"missing {name}; populate .env")
    return value


def compile_pausable() -> tuple[list[dict[str, object]], str]:
    """Compile with py-solc-x without adding a full Hardhat toolchain."""
    installed = {
        str(v) for v in solcx.get_installed_solc_versions(solcx_binary_path=SOLCX_DIR)
    }
    if SOLC_VERSION not in installed:
        print(f"installing solc {SOLC_VERSION} (first run, about 30 seconds)")
        solcx.install_solc(SOLC_VERSION, solcx_binary_path=SOLCX_DIR)

    compiled = solcx.compile_files(
        [str(HERE / "Pausable.sol")],
        output_values=["abi", "bin"],
        solc_binary=get_executable(SOLC_VERSION, solcx_binary_path=SOLCX_DIR),
    )
    key = next(k for k in compiled if k.endswith(":Pausable"))
    return compiled[key]["abi"], compiled[key]["bin"]


def main() -> None:
    load_dotenv(HERE / ".env")

    rpc = require_env("RPC_HTTP")
    account = Account.from_key(require_env("DEPLOYER_PRIVATE_KEY"))
    w3 = Web3(Web3.HTTPProvider(rpc))

    if not w3.is_connected():
        raise SystemExit("RPC is unavailable; check RPC_HTTP in .env")

    chain_id = w3.eth.chain_id
    balance = w3.eth.get_balance(account.address)
    if chain_id != EXPECTED_CHAIN_ID:
        raise SystemExit(
            f"chain_id={chain_id}; expected {EXPECTED_CHAIN_ID} (base-sepolia); deploy refused"
        )

    print(f"chain_id = {chain_id} (base-sepolia)")
    print(f"deployer = {account.address}")
    print(f"balance  = {w3.from_wei(balance, 'ether')} ETH")

    if balance == 0:
        raise SystemExit("zero balance; obtain test ETH from ethglobal.com/faucet")

    abi, bytecode = compile_pausable()
    contract = w3.eth.contract(abi=abi, bytecode=bytecode)

    # Use "pending", not "latest". If an earlier transaction is still in the
    # mempool, "latest" can return a stale nonce and accidentally replace it.
    nonce = w3.eth.get_transaction_count(account.address, "pending")

    # EIP-1559: obtain the priority fee from the node and allow a 2x base-fee
    # margin so the transaction can survive short-term fee movement.
    base_fee = w3.eth.get_block("latest")["baseFeePerGas"]
    priority = w3.eth.max_priority_fee
    max_fee = base_fee * 2 + priority

    print(f"base_fee = {w3.from_wei(base_fee, 'gwei'):.4f} gwei")
    print(f"priority = {w3.from_wei(priority, 'gwei'):.4f} gwei")
    print(f"max_fee  = {w3.from_wei(max_fee, 'gwei'):.4f} gwei")

    gas = contract.constructor().estimate_gas({"from": account.address})
    tx = contract.constructor().build_transaction(
        {
            "from": account.address,
            "nonce": nonce,
            "chainId": chain_id,
            "gas": int(gas * 1.2),  # estimate_gas reflects only the current state
            "maxPriorityFeePerGas": priority,
            "maxFeePerGas": max_fee,
        }
    )

    signed = account.sign_transaction(tx)
    started = time.monotonic()
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    # Web3.to_hex is stable across HexBytes versions with different .hex() behavior.
    print(f"\ndeploy tx = {Web3.to_hex(tx_hash)}")
    print("waiting for receipt ...")

    try:
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)
    except TimeExhausted as exc:
        print(
            "Deployment outcome is indeterminate. Do not deploy again until "
            f"transaction {Web3.to_hex(tx_hash)} and nonce {nonce} are reconciled."
        )
        raise SystemExit(2) from exc
    elapsed = time.monotonic() - started

    if receipt["status"] != 1:
        raise SystemExit(f"deployment reverted with receipt status=0: {receipt}")

    address = receipt["contractAddress"]
    print(f"\ncontract  = {address}")
    print(f"gas used  = {receipt['gasUsed']}")
    print(f"send to receipt = {elapsed:.1f} s; record in FINDINGS.md")
    print(f"basescan  = https://sepolia.basescan.org/address/{address}")

    (HERE / "deployed.json").write_text(
        json.dumps({"address": address, "abi": abi}, indent=2),
        encoding="utf-8",
    )
    print("\ndeployed.json written. Next: python pause_tx.py true")


if __name__ == "__main__":
    main()
