# Write-path spike — Base Sepolia

Purpose: validate Python signing, EIP-1559 fees, nonce handling, receipt outcomes,
confirmation waiting and state re-read before product implementation begins.

This is throwaway preparation code. Product code reimplements the verified
semantics with durable reservation and tests.

## Setup

```powershell
cd 'D:\NexGuard Sentinel\spikes\writepath'
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
Copy-Item env.example .env
# Fill RPC_HTTP and a separate testnet-only DEPLOYER_PRIVATE_KEY.
```

Never reuse a wallet holding real assets. The script aborts unless RPC chain ID
is Base Sepolia (`84532`) and the sender matches the deployed guardian.

## Local verification

```powershell
.\.venv\Scripts\python.exe -m ruff check .
.\.venv\Scripts\python.exe -m pytest
.\.venv\Scripts\python.exe -m mypy deploy.py pause_tx.py
```

## Live sequence

```powershell
.\.venv\Scripts\python.exe deploy.py
.\.venv\Scripts\python.exe pause_tx.py true
.\.venv\Scripts\python.exe pause_tx.py true
.\.venv\Scripts\python.exe pause_tx.py true --force-estimate
.\.venv\Scripts\python.exe pause_tx.py false
.\.venv\Scripts\python.exe pause_tx.py true --dry-run
```

Expected meanings:

| Scenario | Expected outcome |
|---|---|
| First state change | `confirmed_success` after configured confirmations and state re-read |
| Same target again | `already_in_desired_state`; no tx sent |
| Same target + `--force-estimate` | provider revert decoded as `NoChange()`; intentional learning path |
| Receipt `status=0` | `confirmed_revert`, not indeterminate |
| Receipt/confirmation timeout | `indeterminate`; no automatic retry |
| State mismatch after success receipt | `indeterminate`; latch in product |

## Timeout and replacement drill

Use `--timeout 1` to exercise the timeout branch. This does not guarantee that a
Base sequencer transaction remains pending; it deliberately tests uncertainty.

```powershell
.\.venv\Scripts\python.exe pause_tx.py true --timeout 1
```

Record the printed tx hash, nonce and original fee. Before any replacement,
inspect tx/receipt/nonce. A replacement uses the same nonce and must be priced
relative to the original transaction. `--nonce N --fee-multiplier 3` is only a
manual drill; the script warns that current base fee alone cannot prove a valid
replacement bump.

## Definition of done

- [x] Local ruff/pytest/mypy checks pass
- [ ] `deployed.json` contains a Base Sepolia contract
- [ ] Pause and unpause are confirmed and state-verified
- [ ] Already-desired path sends no transaction
- [ ] `NoChange()` decoder is observed with `--force-estimate`
- [ ] Timeout is classified as indeterminate
- [ ] Measurements and exact tool versions are recorded in `FINDINGS.md`
