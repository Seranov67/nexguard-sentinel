# NexGuard Sentinel — execution plan, 4–13 September 2026

> All times are Europe/Kyiv. The official hard deadline is 13 September at
> 19:00 Kyiv. The internal target is 17:00. The exact hacking start must be
> confirmed in the authenticated Dashboard before the first event commit.

## Locked decisions

1. Target only The Graph AI/Continuity until the core flow is complete.
2. Preserve the full `nexguard-edge-resilience` history and mark the baseline.
3. Use live Graph provider data for meaningful AI classification/automation.
4. Keep deterministic `ActionPolicy` as final authority.
5. Automated authority is pause-only; human owner alone may unpause.
6. Do not cut durable reservation, reconciliation, deduplication, chain guards,
   confirmation waiting, or final state verification.

## Gate 0 — before event implementation

- [x] Audit rules, architecture, disclosure, threat model, and config.
- [x] Install Python 3.11, exact spike dependencies, solc, Graph CLI, and Gitleaks.
- [x] Pass local write-path unit/type/lint/compile checks.
- [x] Prepare the Graph query client and document CLI dependency risk.
- [x] Create and restore-verify a local snapshot.
- [ ] Verify the exact hacking-start time in the Dashboard.
- [ ] Deploy the Pausable spike to Base Sepolia.
- [ ] Exercise pause, unpause, already-desired, revert, and timeout semantics.
- [ ] Deploy a minimal Studio Subgraph and query a live event.
- [ ] Record write, indexing, event-appearance, and GraphQL latency.
- [ ] Create and verify an off-device backup.

## Day 0 — after the confirmed start

- fetch and verify the Continuity base repository;
- record the confirmed start in `docs/COMPLIANCE.md`;
- tag the final pre-event commit as `pre-ethonline-2026`;
- create `feature/ethonline-sentinel` after the start;
- import disclosure, attribution, AI logs, specs, and threat model with pre-event labels;
- add Python 3.11 package config, exact lock, Ruff, strict mypy, pytest, and CI.

**Gate 1:** a clean checkout installs and runs lint/type/test; the baseline diff
unambiguously separates prior and event work.

## 5 September — contracts and live data

- implement a keeper pause-only Guardian and owner-only attributed unpause;
- implement a deliberately vulnerable testnet Vault that reads Guardian state;
- add access-control, duplicate-reference, and pause-enforcement tests;
- deploy Guardian first, Vault second;
- index immutable Withdrawal entities with transaction hash + log index IDs;
- return a live Withdrawal through The Graph.

**Gate 2:** the live Graph entity is visible, and manual pause blocks a subsequent
Vault operation.

## 6 September — minimum end-to-end loop

- durable cursor, ascending pagination, deduplication, and confirmation rewind;
- deterministic threshold detection and incident lifecycle;
- atomic `check_and_reserve` before action;
- persist transaction hash immediately after broadcast;
- receipt, confirmations, state re-read, finalise/reconcile;
- happy path without UI or Telegram.

**Gate 3:** a live Graph event produces one verified automatic pause; duplicate
delivery produces no second transaction.

## 7–10 September — qualification and hardening

- restart/reconciliation and concurrency tests;
- explicit success, revert, already-desired, and indeterminate outcomes;
- canonical incident references and idempotent audit trail;
- durable notification outbox;
- structured AI classifier over Graph-derived features;
- invalid, adversarial, timed-out, or low-confidence AI output refuses action;
- Base Sepolia smoke run and Dashboard check-ins when forms are actually available;
- freeze features on 10 September.

## 11–13 September — submission

- run clean-clone installation and three complete demo rehearsals;
- finalize README, diagram, baseline diff, limitations, disclosure, and AI records;
- verify addresses, transaction links, Subgraph ID/version, and live query;
- scan working tree and full Git history with Gitleaks;
- record a 2–4 minute, ≥720p, human-narrated video without speed-up or mobile capture;
- test all public links anonymously;
- select The Graph AI/Continuity in the submission form;
- submit by the internal 17:00 target on 13 September;
- reserve 17:00–19:00 only for upload contingency.

## Scope reduction order

1. Any second or third sponsor.
2. Dashboard/frontend.
3. Multi-protocol generalization.
4. Elaborate AI explanations or visual polish.
5. Separate proof transaction when the atomic pause event already contains the ref.
