# NexGuard Sentinel — operational checklist

> Synchronized with [`PLAN.md`](PLAN.md) on 4 September 2026.

## Gate 0 — preparation

- [x] Full audit completed.
- [x] Official rules and The Graph requirements verified.
- [x] Disclosure, attribution, AI records, and threat model prepared.
- [x] `sentinel.yaml` semantics corrected.
- [x] Python 3.11 environment and exact dependencies installed.
- [x] Write-path local tests, Ruff, strict mypy, and Solidity compile pass.
- [x] Local pinned Graph CLI and Python query client work.
- [x] First-party Gitleaks scan is clean.
- [ ] English-language local backup passes restore/hash comparison.
- [ ] Dashboard hacking-start timestamp recorded.
- [ ] Disposable Base Sepolia wallet funded with faucet ETH.
- [ ] Pausable deployed to Base Sepolia.
- [ ] Pause/unpause/already-desired/revert/timeout paths observed live.
- [ ] Live Studio Subgraph deployed and queried.
- [ ] Live latency fields completed in both spike findings files.
- [ ] Off-device backup restored and hash-verified.

## Gate 1 — event baseline

- [ ] Full prior Git history preserved.
- [ ] Final pre-event hash verified after fetch.
- [ ] `pre-ethonline-2026` tag created after confirmed start.
- [ ] Event feature branch created after confirmed start.
- [ ] Pre-event documents imported with provenance.
- [ ] Event Python package, exact lock, CI, Ruff, strict mypy, and pytest work.

## Gate 2 — contracts and Graph

- [ ] Keeper can pause only.
- [ ] Owner/human alone can unpause with reason hash.
- [ ] Vault reads Guardian pause state.
- [ ] Contract tests pass.
- [ ] Guardian then Vault deployed.
- [ ] Subgraph entity ID uses transaction hash + log index.
- [ ] Live Withdrawal returned by Graph.
- [ ] Manual pause blocks another Vault operation.

## Gate 3 — safe automation

- [ ] Durable cursor, deduplication, and confirmation rewind.
- [ ] Signal model and deterministic threshold.
- [ ] Atomic durable reservation before action.
- [ ] Transaction hash persisted immediately after send.
- [ ] Confirmations, state re-read, finalisation, and latch.
- [ ] Duplicate delivery creates no second transaction.
- [ ] Restart and concurrency tests pass.
- [ ] AI classifier consumes Graph-derived features.
- [ ] Invalid/low-confidence AI output refuses action.
- [ ] Notification outbox survives restart.

## Submission gate

- [ ] Clean-clone runbook and three demo rehearsals pass.
- [ ] README, architecture, baseline diff, limitations, and evidence are final.
- [ ] Contract addresses, transaction links, and Subgraph ID/version are verified.
- [ ] `AI_USAGE.md`, `AI_PROMPTS.md`, `DISCLOSURE.md`, and licenses are final.
- [ ] Working-tree and full-history Gitleaks scans are clean.
- [ ] Public repo and video work without authentication.
- [ ] Video is 2–4 minutes, ≥720p, human narrated, not sped up/mobile recorded.
- [ ] The Graph AI/Continuity pool is selected.
- [ ] Internal submission target met by 13 September 17:00 Kyiv.
- [ ] Dashboard confirmation exists before the official 19:00 Kyiv deadline.
