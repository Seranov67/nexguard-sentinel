# Compliance evidence register

> This is a factual register, not marketing copy. Use `verified`, `pending`,
> `not applicable`, or `failed`; never infer completion from planned work.

## Rule-source verification

| Checked at (Kyiv) | Source | What was verified | Status |
|---|---|---|---|
| 2026-09-03 | <https://ethglobal.com/events/ethonline2026/info/details> | Deadline, video, Continuity, version control, AI disclosure, spec artifacts, judging | verified |
| 2026-09-03 | <https://ethglobal.com/events/ethonline2026/prizes> | The Graph AI/Continuity pool and qualification requirements | verified |
| pending | Authenticated Hacker Dashboard | Exact hacking start, check-ins, team state, final form | pending |

## Pre-event baseline evidence

| Item | Evidence | Status |
|---|---|---|
| Existing repository | <https://github.com/Seranov67/nexguard-edge-resilience> | verified |
| Last observed pre-event commit | `fa202e994a77ea365061f6ac609daea1b5ad60dd` — 2026-07-25T15:37:50+03:00 | verified locally 2026-09-03 |
| History at verification | 26 commits; local `main` matched `origin/main`; clean worktree | verified locally 2026-09-03 |
| License | MIT; copyright notice preserved | verified locally 2026-09-03 |
| Baseline tag | `pre-ethonline-2026` on final verified pre-start commit | pending until hacking start |
| Event branch | Created only after confirmed start | pending |

The commit above is the last commit observed during this audit, not permission to
tag blindly. Immediately before the event, fetch and re-check `origin/main`; record
the final hash and Dashboard-confirmed start before creating the tag/branch.

## Preparation workspace evidence

| Evidence | Result | Status |
|---|---|---|
| Python toolchain | Python 3.11.9; exact spike dependencies | verified |
| Write-path local checks | 6 pytest tests; Ruff pass; strict mypy pass | verified |
| Solidity preparation compile | solc 0.8.24; 11 ABI entries; 1545 bytecode bytes | verified |
| Graph CLI | local `@graphprotocol/graph-cli` 0.98.1 on Node 22.17.1 | verified |
| Graph CLI dependency audit | 15 advisories: 1 critical, 10 high, 4 moderate | open risk |
| Secret scan | Gitleaks 8.30.1, first-party workspace: no leaks | verified |
| Local backup | English-language snapshot `NexGuard-Sentinel-prestart-2026-09-04-english.zip` | pending verification |
| Off-device backup | No evidence yet | pending |

These results apply only to pre-event spikes/preparation, not to the future
submission implementation.

## Qualification evidence still required

| Requirement | Evidence artifact | Status |
|---|---|---|
| Dashboard-confirmed hacking start | timestamp/screenshot or written schedule note | pending |
| Event-only history | baseline tag, dated commits, `git diff --stat <tag>..HEAD` | pending |
| Public repository | anonymous/incognito access test | pending |
| Live Graph provider | Subgraph ID, public-safe endpoint form, query and response metadata | pending |
| Meaningful AI use | schema, prompt/version, Graph-derived inputs, output and policy trace | pending |
| Working automation | Graph entity → reservation → tx → confirmations → state re-read | pending |
| Testnet contracts | chain ID, addresses, deployment tx hashes, explorer links | pending |
| Reproducibility | clean-clone install/test/run record | pending |
| Demo video | public URL, duration 2–4 min, ≥720p, human narration | pending |
| Disclosure | final prior/new table and license notices | pending final review |
| AI transparency | per-file activity log and prompt/spec archive | pending final review |
| Partner selection | The Graph AI/Continuity selected in submission form | pending |
| Submission | Dashboard confirmation before hard deadline | pending |

## Event evidence log template

| Time (Kyiv) | Action | Evidence | Result |
|---|---|---|---|
| | Hacking start verified | Dashboard/schedule reference | |
| | Baseline created | commit + tag | |
| | Deployment | chain/address/tx | |
| | Graph deploy | Subgraph ID/version | |
| | Live query | indexed block/entity/latency | |
| | End-to-end run | incident ref/tx/final state | |
| | Check-in | Dashboard confirmation | |
| | Submission | Dashboard confirmation | |
