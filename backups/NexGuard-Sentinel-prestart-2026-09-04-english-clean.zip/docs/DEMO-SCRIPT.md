# Demo video script

> Target length: 3:30. Final claims and links must come from `COMPLIANCE.md`.

## Official format gate

- 2–4 minutes; uploads outside the range are rejected;
- at least 720p;
- no speed-up;
- no mobile-phone recording;
- no text-to-speech or AI voiceover; use clear human narration;
- editing out unnecessary waiting is allowed.

Source: <https://ethglobal.com/events/ethonline2026/info/details>.

## Storyboard

| Time | Screen | Narration point |
|---|---|---|
| 0:00–0:20 | Abnormal withdrawal sequence | Detection without a safe response loop leaves a sleeping human in the critical path. |
| 0:20–0:40 | Architecture | The Graph provides live indexed data; deterministic policy remains final authority. |
| 0:40–2:15 | Live end-to-end flow | Show evidence and state transitions, not slides. |
| 2:15–2:45 | Policy and durable reservation | One canonical event can reserve at most one action, including after restart. |
| 2:45–3:10 | Existing history and baseline diff | Prior resilience primitives are disclosed; event work is isolated by the baseline. |
| 3:10–3:30 | Config, Subgraph ID, contract | The Graph is load-bearing; automated authority is pause-only. |

## Central live sequence

1. Start Sentinel and show chain ID, Graph head, and cursor without secrets.
2. Submit a series of Base Sepolia Vault withdrawals.
3. Show the canonical Graph entity and deterministic signal.
4. Show Graph-derived features entering the structured AI classifier.
5. Show valid severity/action/confidence output and deterministic policy approval.
6. Show atomic reservation, `pause(incidentRef, severity)`, and saved tx hash.
7. Show receipt success, confirmations, and `paused() == true` re-read.
8. Replay the entity and show that no second transaction is created.
9. Show a subsequent Vault operation reverting because the Guardian is paused.

## Negative-path evidence

- malformed or low-confidence AI output → refuse and notify;
- duplicate entity → existing reservation/result;
- timeout after broadcast → indeterminate, no automatic resend;
- unpause → owner/human only with a reason hash.

If live latency is too long, edit out waiting as ETHGlobal permits. Internal
transparency standard: display elapsed time rather than speeding up footage.

## Recording gate

1. Complete three rehearsals from a known clean state.
2. Hide `.env`, wallet extensions, deploy/gateway keys, RPC URLs, and OS notifications.
3. Show real explorer/Graph links and the baseline diff.
4. Make no production-readiness claim: this is a testnet prototype, not an audit.
5. Verify duration, resolution, audio, and anonymous access after upload.

## Description draft

    NexGuard Sentinel extends an existing resilience engine with a pause-only,
    crash-safe incident-response loop for on-chain protocols. It consumes live
    protocol data through The Graph, derives structured AI context, applies
    deterministic safety policy, reserves one idempotent action, pauses a Guardian
    contract, and verifies the final on-chain state.

    ETHOnline 2026 — target: The Graph AI/Continuity.
    Prior work and the event baseline are disclosed in the repository.
