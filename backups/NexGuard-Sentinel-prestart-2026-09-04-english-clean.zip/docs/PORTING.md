# Porting the existing resilience core

> Extend `nexguard-edge-resilience`; do not create a history-free repository.
> Every reused file needs source-path attribution and a baseline diff.

## Reuse map

| Prior source | Event target | Adaptation rule |
|---|---|---|
| recovery guards | `sentinel/core/policy.py` | preserve cooldown/window/latch; never authorize unpause |
| incident state machine | `sentinel/core/incident.py` | remove import-time metric globals; use canonical IDs |
| action/verification pattern | `sentinel/core/executor.py` | reserve → save tx hash → receipt → confirmations → state re-read |
| `latch-agent` semantics | policy/reconciliation tests | durable latch and operator-attributed reset |
| `llm-log-monitor` patterns | `sentinel/detect/ai.py` | schema-valid output; AI is never final authority |

Do not port filesystem restore, Docker management, gateway config checking, or a
domain-specific FastAPI wrapper.

## Invariants

1. Keeper can pause only; owner/human alone can unpause.
2. One canonical Graph entity reserves at most one action.
3. Persist the transaction hash before waiting for a receipt.
4. Timeout means indeterminate and reconciliation, never blind resend.
5. Success requires receipt status, confirmations, and final state re-read.
6. Invalid/low-confidence AI output refuses action.
7. Notifications use a durable outbox or tracked task registry.

## Event implementation order

1. Verify and tag the final pre-event commit after the confirmed start.
2. Add `ATTRIBUTION.md` with exact source paths and licenses.
3. Port pure state/policy models and lock behavior with tests.
4. Add durable reservation and reconciliation to the executor.
5. Connect the Graph source, then AI classifier, then notifier.
6. Publish a prior/adapted/new file table and baseline diff.
