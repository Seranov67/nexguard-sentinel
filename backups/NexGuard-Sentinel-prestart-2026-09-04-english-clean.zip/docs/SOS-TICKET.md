# Optional ETHGlobal support ticket

> Status: not sent. The public rules and prize page are sufficient unless the
> Dashboard does not expose the expected Continuity pool or start information.

## Draft

```text
Hi! I plan to submit to the ETHOnline 2026 Continuity Track with a new on-chain
incident-response feature built on this existing MIT repository:
https://github.com/Seranov67/nexguard-edge-resilience

The repository was public before the event. I will preserve its complete history,
tag the final verified pre-event commit after the confirmed hacking start, and
clearly document prior work. The new event-period feature is intended to use live
The Graph data, structured AI incident classification, guarded pause-only execution,
post-action verification, and testnet contracts.

The prize page lists "Best AI Tooling or AI Use Case with The Graph (Continuity)."
Can you confirm that this is the correct pool and clarify the exact hacking-start
timestamp shown for my account?

For completeness, the prior repository contains a pending DoraHacks placeholder
but no known published BUIDL URL. A separate pre-event project,
https://github.com/Seranov67/latch-agent, informs the durable policy design; its
TypeScript implementation will not be presented as new work.

Thank you!
```

## Communication log

| Date/time (Kyiv) | Channel | Result |
|---|---|---|
| — | — | Not sent |
