# Guardian and demo Vault — contract specification

> Pre-event interface specification. Solidity implementation starts after
> hacking opens. Mainnet and real funds are explicitly out of scope.

## Security model

- `keeper` is a hot, testnet-only signer. It may **pause only**.
- `owner` is a human-controlled address. It rotates the keeper and unpauses.
- Off-chain policy improves operational safety but is not an on-chain security
  boundary; the contract enforces the pause-only limitation itself.
- The incident reference is emitted atomically with the pause state change.
- A duplicate reference cannot create a second incident.

## Interface

```solidity
interface IGuardian {
    function paused() external view returns (bool);
    function keeper() external view returns (address);
    function owner() external view returns (address);
    function incidentCount() external view returns (uint256);
    function seenIncident(bytes32 ref) external view returns (bool);

    // Automated path: keeper only, pause only.
    function pause(bytes32 ref, uint8 severity) external returns (uint256 id);

    // Human path: owner only, reason is committed on-chain.
    function unpause(bytes32 reasonHash) external;
    function setKeeper(address next) external;

    event Paused(
        bytes32 indexed incidentRef,
        uint8 severity,
        address indexed by,
        uint256 at
    );
    event IncidentRecorded(
        uint256 indexed id,
        bytes32 indexed ref,
        uint8 severity,
        address indexed by,
        uint256 at
    );
    event Unpaused(bytes32 indexed reasonHash, address indexed by, uint256 at);
    event KeeperChanged(address indexed from, address indexed to);

    error NotKeeper();
    error NotOwner();
    error AlreadyPaused();
    error NotPaused();
    error DuplicateIncident();
    error InvalidSeverity();
    error ZeroAddress();
    error ZeroReference();
}
```

## State-transition rules

| Call | Preconditions | State/event |
|---|---|---|
| `pause(ref, severity)` | keeper; not paused; ref nonzero/unseen; severity 0..2 | `paused=true`, ref marked, counter incremented, both audit events emitted |
| `unpause(reasonHash)` | owner; paused; reason nonzero | `paused=false`, `Unpaused` emitted |
| `setKeeper(next)` | owner; next nonzero/different | keeper changed |

The executor pre-reads `paused()`. If it is already true, it returns
`already_in_desired_state` without reserving/sending another action. A race can
still produce `AlreadyPaused`; the client then re-reads state before classifying
the outcome.

## Canonical incident reference

`ref = keccak256(UTF8(canonical_json_v1))`, where:

- envelope contains explicit `schema_version: 1`;
- keys are sorted;
- separators are `,` and `:` without whitespace;
- timestamps are UTC RFC 3339 strings;
- large integers are decimal strings;
- UTF-8 is used with non-ASCII preserved.

A golden-vector test must fix one JSON payload and its expected hash.

## Intentionally vulnerable testnet Vault

The demo contract holds a tiny faucet-funded balance and deliberately allows any
caller to withdraw while the Guardian is not paused. This is an explicit testnet
vulnerability used to demonstrate the response loop, not production vault code.

```solidity
interface IGuardianView {
    function paused() external view returns (bool);
}

contract VulnerableVault {
    IGuardianView public immutable guardian;

    event Withdrawal(address indexed who, uint256 amount, uint256 at);
    error Paused();
    error TransferFailed();

    constructor(address guardianAddress) {
        guardian = IGuardianView(guardianAddress);
    }

    receive() external payable {}

    function withdraw(uint256 amount) external {
        if (guardian.paused()) revert Paused();
        (bool ok, ) = msg.sender.call{value: amount}("");
        if (!ok) revert TransferFailed();
        emit Withdrawal(msg.sender, amount, block.timestamp);
    }
}
```

Deploy Guardian first, then Vault with the Guardian address. Fund Vault only with
a minimal amount of Base Sepolia faucet ETH.

## Minimum contract tests

- non-keeper cannot pause;
- keeper pause updates state and atomically emits both events;
- keeper cannot unpause;
- owner can unpause with nonzero reason;
- zero/duplicate ref and invalid severity revert;
- non-owner cannot rotate keeper;
- zero keeper address reverts;
- old keeper loses access after rotation;
- Vault withdrawal succeeds before pause and reverts after pause;
- no real-network chain ID is accepted by deployment scripts.
