# NexGuard Sentinel — preparation workspace

> A pause-only incident-response system for on-chain protocols.
> Target: ETHOnline 2026, The Graph AI/Continuity pool. Actual pool selection
> remains pending in the Hacker Dashboard. Official submission deadline:
> 13 September 2026, 12:00 pm EDT / 19:00 Europe/Kyiv.

This directory contains pre-event specifications, templates, evidence, and
throwaway spikes. It is deliberately not the submission Git repository. Product
implementation begins only after the exact hacking start is confirmed in the
authenticated Dashboard. The conservative planning boundary is 4 September at
19:00 Kyiv; it is not quoted as a public rule.

## Strategy

The Continuity submission will extend the existing MIT-licensed
[`nexguard-edge-resilience`](https://github.com/Seranov67/nexguard-edge-resilience)
repository, preserve its complete history, tag the verified final pre-event
commit, and make the event-only diff easy to audit.

The Graph must be load-bearing: live provider data must drive meaningful AI
classification, decisions, or automation. Deterministic policy remains the final
authority, and the automated signer can pause but never unpause.

## Documentation map

| Document | Purpose |
|---|---|
| [`AUDIT-2026-09-03.md`](AUDIT-2026-09-03.md) | Current audit, risks, and readiness verdict |
| [`PLAN.md`](PLAN.md) | Execution plan through submission |
| [`CHECKLIST.md`](CHECKLIST.md) | Operational gates |
| [`docs/RULES.md`](docs/RULES.md) | Verified organizer/partner rules versus internal controls |
| [`docs/COMPLIANCE.md`](docs/COMPLIANCE.md) | Evidence register with verified and pending status |
| [`docs/PRIZES.md`](docs/PRIZES.md) | The Graph AI/Continuity qualification strategy |
| [`docs/SPEC.md`](docs/SPEC.md) | Architecture and failure semantics |
| [`docs/THREAT_MODEL.md`](docs/THREAT_MODEL.md) | Trust boundaries and safety invariants |
| [`docs/DISCLOSURE.md`](docs/DISCLOSURE.md) | Pre-existing versus event-period work |
| [`docs/ATTRIBUTION.md`](docs/ATTRIBUTION.md) | Source, license, and reuse register |
| [`docs/AI_USAGE.md`](docs/AI_USAGE.md) | Per-area AI assistance log |
| [`docs/AI_PROMPTS.md`](docs/AI_PROMPTS.md) | Preserved prompts and known evidence gaps |
| [`docs/DEPENDENCIES.md`](docs/DEPENDENCIES.md) | Exact preparation toolchain and security status |
| [`submission/FORM-DRAFT.md`](submission/FORM-DRAFT.md) | Evidence-backed submission template |
| [`AUDIT.md`](AUDIT.md) | English summary of the superseded 1 September audit |

## Workspace boundaries

| Area | Purpose | Submission treatment |
|---|---|---|
| `docs/`, `templates/` | Pre-event specifications and prose | Include only with explicit pre-event provenance |
| `spikes/` | Throwaway learning prototypes | Reimplement verified semantics; do not copy mechanically |
| `submission/` | Local submission notes | Replace every `PENDING` from verified evidence |
| `backups/` | Local recovery snapshots | Do not publish as project source |

## Verified preparation status

- Python 3.11.9 virtual environment and exact spike dependencies are installed.
- solc 0.8.24 compiles the spike contract: 11 ABI entries, 1,545 bytecode bytes.
- Write-path checks pass: 6 pytest tests, Ruff, and strict mypy.
- Local Graph CLI 0.98.1 runs on Node 22.17.1; `query.py` compiles.
- Gitleaks 8.30.1 reports no leaks in first-party workspace files.
- The current local recovery snapshot passed a 45-file hash comparison.
- Graph CLI still has documented upstream transitive advisories.

## Open gates

- confirm the exact hacking start and team/pool status in the Dashboard;
- create a disposable Base Sepolia wallet and fund it only with faucet ETH;
- deploy and measure the write path;
- deploy a live Studio Subgraph and record query/event latency;
- create and verify an off-device backup;
- create the event tag/branch in the real Continuity repository after start.

Never paste a private key, deploy key, gateway key, or sensitive wallet
identifier into source control, documentation, chat, logs, or demo footage.
