# Submission repository strategy

This directory is only a note. It is not initialized as Git and does not contain
the ETHOnline submission.

Use [`FORM-DRAFT.md`](FORM-DRAFT.md) as a placeholder-safe submission template;
replace `PENDING` only from the compliance evidence register.

## At the Dashboard-confirmed hacking start

Current conservative planning boundary: 4 September, 19:00 Kyiv. Do not create
the event commit/tag based only on this note; verify the authenticated Dashboard
or official schedule first and record the timestamp in `docs/COMPLIANCE.md`.

Use the existing `nexguard-edge-resilience` Git history so the Continuity lineage
is directly auditable:

```text
git switch main
git pull --ff-only
git tag pre-ethonline-2026 <verified-last-pre-event-commit>
git switch -c feature/ethonline-sentinel
```

If a separate `nexguard-sentinel` GitHub remote is desired, push the complete
existing history to it. Do not create a history-free repository and do not
squash the prior commits.

## First event-period slices

1. `docs: disclose baseline and define Sentinel scope`
2. `chore: add Python package checks and CI`
3. `contracts: add pause-only guardian and protected demo vault`
4. `subgraph: index live vault events`
5. `feat: ingest Graph events with durable cursor`

Commit boundaries follow completed, testable slices. Do not split documents into
artificial commits merely to increase commit count.

## Required lineage evidence

- baseline tag and full commit hash;
- table of pre-existing versus event-period work;
- links to `nexguard-edge-resilience`, `latch-agent` and relevant licenses;
- `git diff --stat pre-ethonline-2026..HEAD` in the final verification notes;
- `DISCLOSURE.md` and daily `AI_USAGE.md`.
- surviving specs/plans plus `AI_PROMPTS.md`, because a spec-driven AI workflow
  was used during preparation.

## Publication gate

- [ ] Repository is public
- [ ] Baseline tag exists on the verified pre-event commit
- [ ] Event commits are after hacking opened
- [ ] `gitleaks dir . --config .gitleaks.toml --redact --no-banner` is clean
- [ ] `gitleaks git . --config .gitleaks.toml --redact --no-banner` is clean
- [ ] `.env` and secrets never entered history
- [ ] Stake-wallet denylist has no matches
- [ ] README separates prior and new work
- [ ] The Graph Subgraph ID and deployment evidence are present
- [ ] Video and all links work without private access
- [ ] Demo is 2–4 minutes, ≥720p, not sped up, not mobile-recorded, with human voice
- [ ] The Graph AI/Continuity pool is selected in the form
- [ ] Submission confirmation exists before 13 September 19:00 Kyiv
