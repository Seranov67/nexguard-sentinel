# CLAUDE.md

Guidance for AI coding tools working in this preparation workspace.

## Read first

1. `AUDIT-2026-09-03.md`
2. `PLAN.md`
3. `CHECKLIST.md`
4. `docs/SPEC.md`
5. `docs/DISCLOSURE.md`

The old `AUDIT.md` is historical and does not override the 3 September audit.

## Workspace boundary

This directory is not the submission Git repository. It contains pre-event
specifications, templates and throwaway spikes. Do not run `git init` here.

New product logic starts after 4 September 2026, 19:00 Europe/Kyiv. The eventual
Continuity submission preserves the full history of `nexguard-edge-resilience`,
tags the last pre-event commit as `pre-ethonline-2026`, and makes the event-only
diff easy to inspect.

Spikes may be changed and run before the event. Their code is not copied
mechanically into the product; verified semantics are reimplemented with tests.

## Current strategy

- Partner target: The Graph AI/Continuity only.
- 0G: not an ETHOnline 2026 sponsor; cancelled.
- Chainlink Automation: do not use; current prize asks for CRE and states that
  Functions/Automation are being deprecated.
- Automatic signer: pause only. Human/owner: unpause.
- The Graph supplies live data; AI performs structured classification; a
  deterministic ActionPolicy remains the final action authority.

## Safety invariants

1. Fail closed on Graph, RPC, storage or AI uncertainty.
2. Reserve an intent durably before sending a transaction.
3. Persist tx hash immediately after send; reconcile unfinished intents on start.
4. Re-read contract state after receipt and confirmation depth.
5. At-least-once event ingestion; effectively-once action via dedupe/idempotency.
6. `already_in_desired_state` is idempotent success, not failure.
7. Never place private keys, deploy keys, API tokens or the stake-wallet address
   in Git, logs, screenshots or demo output.
8. Every material AI-assisted change is logged in `docs/AI_USAGE.md` the same day.
9. Disclosure is over-inclusive; preserve licenses and copyright notices.

## Spike commands

Target Python is 3.11. On this host `python` resolves to 3.11.9; the Windows
`py` launcher still has no registered interpreter.

```powershell
cd 'D:\NexGuard Sentinel\spikes\writepath'
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item env.example .env
# Fill RPC_HTTP and a testnet-only DEPLOYER_PRIVATE_KEY.
.\.venv\Scripts\python.exe deploy.py
.\.venv\Scripts\python.exe pause_tx.py true
.\.venv\Scripts\python.exe pause_tx.py false
.\.venv\Scripts\python.exe pause_tx.py true --dry-run
```

The Graph CLI must be installed locally at a pinned version, not globally. Record
the exact version and live latency in `spikes/thegraph/FINDINGS.md`.

## Verification before handoff

- parse/compile all Python and Solidity sources;
- run unit/integration tests;
- validate YAML and GraphQL variable declarations;
- check all local Markdown links;
- scan secrets and Git history;
- state explicitly which live checks could not run because credentials or
  account interaction were unavailable.
