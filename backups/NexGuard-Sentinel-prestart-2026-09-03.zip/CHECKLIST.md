# NexGuard Sentinel — робочий чекліст

> Синхронізовано з [`PLAN.md`](PLAN.md) 3 вересня 2026.

## До старту — Gate 0

- [x] Повний аудит виконано
- [x] Sponsor strategy оновлено: The Graph AI/Continuity only
- [x] Disclosure і правила синхронізовано
- [x] `sentinel.yaml` виправлено
- [x] Write-path spike виправлено
- [x] Python 3.11 venv працює
- [x] Pinned dependencies встановлено
- [x] Gitleaks first-party workspace scan чистий
- [ ] Pausable задеплоєно в Base Sepolia
- [ ] Pause / unpause / already-desired перевірені
- [ ] Timeout/indeterminate branch перевірений
- [x] `spikes/writepath/FINDINGS.md` заповнено (live fields pending)
- [x] Локальний pinned Graph CLI працює
- [ ] Live Studio Subgraph задеплоєно
- [ ] `query.py` повертає live подію
- [x] `spikes/thegraph/FINDINGS.md` заповнено (live fields pending)
- [ ] Backup створено і restore перевірено

## 4 вересня — Gate 1

- [ ] Не починати event work до 19:00 Kyiv
- [ ] Повна prior Git history збережена
- [ ] Baseline tag `pre-ethonline-2026`
- [ ] Event feature branch створено після старту
- [ ] `DISCLOSURE.md`, `AI_USAGE.md`, `THREAT_MODEL.md`
- [ ] Python 3.11 package + exact lock
- [ ] Ruff + mypy strict + pytest + CI запускаються

## 5 вересня — Gate 2

- [ ] Keeper може тільки pause
- [ ] Owner/human only unpause із reason hash
- [ ] Vault/Simulator читає Guardian state
- [ ] Contract tests зелені
- [ ] Guardian deploy → Vault deploy
- [ ] Subgraph entity ID = tx hash + log index
- [ ] Live Withdrawal повертається через Graph
- [ ] Manual pause блокує повторну operation

## 6 вересня — Gate 3

- [ ] Durable cursor + dedupe + confirmation rewind
- [ ] `Signal` + deterministic threshold
- [ ] Durable `check_and_reserve`
- [ ] Tx hash зберігається одразу після send
- [ ] Confirmations + re-read + finalise/latch
- [ ] Live event → automatic verified pause
- [ ] Duplicate delivery → жодної другої tx

## 7–10 вересня — hardening і feature freeze

- [ ] Restart/reconcile tests
- [ ] `already_in_desired_state`
- [ ] Receipt status=0 / timeout / RPC failure semantics
- [ ] Idempotent/canonical audit ref
- [ ] Telegram outbox/task registry
- [ ] Check-in #1
- [ ] Structured AI classifier над Graph data
- [ ] Invalid/low-confidence AI → refuse + notify
- [ ] Policy/cursor/classifier/contract/integration/concurrency tests
- [ ] Base Sepolia smoke
- [ ] Feedback session
- [ ] Check-in #2
- [ ] Feature freeze 10 вересня

## 11–13 вересня — submission

- [ ] Fresh-clone runbook пройдено
- [ ] Три demo rehearsals
- [ ] README + diagram + baseline diff + limitations
- [ ] Deployed addresses і Graph ID перевірені
- [ ] `AI_USAGE.md` і `DISCLOSURE.md` фінальні
- [ ] Gitleaks + Git history + wallet denylist чисті
- [ ] Відео 2–4 хв, ≥720p, власний голос, без speed-up/TTS
- [ ] Repo public
- [ ] The Graph Continuity обрано
- [ ] Форму відправлено до 17:00 13 вересня
