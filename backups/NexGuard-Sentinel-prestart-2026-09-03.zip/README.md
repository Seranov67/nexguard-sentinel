# NexGuard Sentinel — preparation workspace

> Автономний incident response для on-chain протоколів.
> ETHOnline 2026, Continuity Track. Submission deadline: 13 вересня, 19:00 Kyiv.

Поточний стан і план відновлення: [`AUDIT-2026-09-03.md`](AUDIT-2026-09-03.md)
та [`PLAN.md`](PLAN.md).

## Правило workspace

Цей каталог не є Git-репозиторієм submission. Тут зберігаються специфікації,
шаблони й throwaway spikes. Нова product logic не пишеться до офіційного старту
4 вересня о 19:00 Kyiv.

Continuity Track дозволяє розвивати існуючий open-source repository. Submission
має зберегти Git-історію `nexguard-edge-resilience`, позначити останній pre-event
commit baseline tag-ом і чітко відокремити prior work від event work.

| Зона | Призначення | Доля |
|---|---|---|
| `docs/`, `templates/` | Specification і submission prose | Переносити з чесним disclosure про pre-event creation |
| `spikes/` | Навчальні прототипи | Не копіювати механічно; переносити лише перевірені рішення |
| `submission/` | Локальні нотатки | Не є submission repository |

## Що читати

| Файл | Навіщо |
|---|---|
| [`AUDIT-2026-09-03.md`](AUDIT-2026-09-03.md) | Поточний повний аудит, ризики й acceptance criteria |
| [`PLAN.md`](PLAN.md) | Актуальний календар 3–13 вересня |
| [`CHECKLIST.md`](CHECKLIST.md) | Операційні гейти |
| [`docs/PRIZES.md`](docs/PRIZES.md) | The Graph AI/Continuity strategy |
| [`docs/SPEC.md`](docs/SPEC.md) | Product architecture |
| [`docs/DISCLOSURE.md`](docs/DISCLOSURE.md) | Межа prior/new work |
| [`docs/THREAT_MODEL.md`](docs/THREAT_MODEL.md) | Trust boundaries, abuse cases і safety invariants |
| [`AUDIT.md`](AUDIT.md) | Історичний аудит 1 вересня |

## Карта

```text
D:\NexGuard Sentinel\
├── AUDIT-2026-09-03.md       поточний аудит
├── AUDIT.md                  історичний аудит 1 вересня
├── PLAN.md                   актуальний план
├── CHECKLIST.md              робочі гейти
├── docs\                     spec, disclosure, rules, demo
├── templates\                sentinel.yaml і env template
├── spikes\
│   ├── writepath\            Python → Base Sepolia transaction
│   ├── thegraph\             Subgraph → GraphQL → Python
│   └── 0g\                   архів: sponsor відсутній на ETHOnline 2026
└── submission\               локальна пам'ятка, не Git repo
```

## Стан на 3 вересня 2026

```text
✅ nexguard-edge-resilience: 26 pre-event commits, MIT, public
✅ latch-agent: durable reservation/reconciliation design source
✅ The Graph Continuity eligibility підтверджена prize page
✅ Sponsor scope скорочено до The Graph AI/Continuity
✅ Повний аудит завершено
✅ Python 3.11 venv, pinned Python dependencies і solc 0.8.24 готові
✅ Write-path unit/type/lint checks зелені
✅ Локальний pinned Graph CLI 0.98.1 і Python query готові
⚠️ Graph CLI має задокументовані upstream transitive advisories
❌ Base Sepolia і The Graph live частини чекають testnet credentials
✅ Gitleaks 8.30.1: tracked workspace scan без витоків
❌ Off-device backup/restore ще не підтверджений
❌ Product package, tests, CI і deployments відсутні
```

Наступний gate: до 4 вересня 17:00 отримати реальну Base Sepolia подію через
live The Graph endpoint і завершити write-path measurements.
