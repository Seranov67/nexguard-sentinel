# ETHOnline 2026 — правила та внутрішні запобіжники

> Перевірено 3 вересня 2026. Official source:
> <https://ethglobal.com/events/ethonline2026/info/details>.
> Усі локальні дати нижче — Europe/Kyiv (EDT + 7 годин у вересні).

## Офіційні вимоги

- Hacking begins: **4 вересня, 19:00 Kyiv**.
- Submission deadline: **13 вересня, 19:00 Kyiv**.
- Demo video: **2–4 хвилини**, щонайменше 720p.
- Не можна speed-up, mobile-phone recording або TTS/AI voiceover.
- Submission містить repository та чітко відділяє reused/prior work від нового.
- Continuity Track дозволяє розвивати існуючий open-source repository або product;
  оцінюється нова функціональність, зроблена під час події.
- Version control має показувати прогрес; великі single commits або відсутня
  history можуть спричинити disqualification.
- AI дозволений, але де і як він допомагав треба документувати. Повністю
  AI-generated submission без meaningful human contribution може втратити
  eligibility.
- У формі можна вибрати до трьох партнерів; конкретна eligibility визначається
  prize page кожного партнера.

## The Graph partner requirements

Для обраного `Best AI Tooling or AI Use Case with The Graph (Continuity)`:

- The Graph має бути load-bearing частиною проєкту;
- використовуються live data від Graph provider (Studio/API key підходить);
- mock/local/static data не кваліфікуються;
- дані мають приводити до reasoning, decision або automation, а не лише print;
- public repository, clear README та 2–4 minute demo video;
- prior work документується, обирається Continuity pool.

Source: <https://ethglobal.com/events/ethonline2026/prizes>.

## Check-ins

Публічна сторінка описує check-in як короткий status update через Hacker
Dashboard: progress, blockers і запит допомоги. Вона не називає пропуск
автоматичним disqualifier. Внутрішнє правило проєкту суворіше: здати обидва
check-ins увечері напередодні дедлайну, щойно Dashboard відкриє форму.

- Check-in #1: планувати на 7 вересня ввечері.
- Check-in #2: планувати на 10 вересня ввечері.

Точний стан і поля форми перевіряються в Dashboard, а не вгадуються з локального
плану.

## Внутрішні правила безпеки

Це наші guardrails, а не дослівні дискваліфікатори ETHGlobal:

1. Нова product logic починається після 4 вересня 19:00.
2. Останній pre-event commit позначається baseline tag-ом; history не squash-иться.
3. Disclosure навмисно over-inclusive.
4. AI usage дописується того самого дня.
5. Keeper wallet — окремий testnet-only ключ із faucet balance.
6. Stake wallet address, private keys, deploy keys і API tokens не потрапляють у
   submission, screen recording або Git history.
7. Автоматичний signer може тільки pause; unpause — human/owner only.
8. Перед кожним public push працюють secret scan і denylist scan.
9. Mainnet та реальні кошти поза scope.

## Submission safety gate

```text
gitleaks detect --source . -v
git log --all --full-history -- .env .env.local secrets.json
rg -n '(PRIVATE_KEY|GRAPH_DEPLOY_KEY|TELEGRAM_BOT_TOKEN)\s*=\s*\S+' .
```

Додатково CI шукає заборонену адресу stake wallet, яка не повинна копіюватись із
preparation docs.
