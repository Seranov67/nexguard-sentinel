# Prior-work disclosure

This document separates work that existed before ETHOnline 2026 from work that
will be produced during the event. The submission is entered in the Continuity
Track. Only the event-period feature work is presented for judging.

## 1. NexGuard Edge Resilience

Repository: <https://github.com/Seranov67/nexguard-edge-resilience>

- License: MIT
- Public since: 25 July 2026
- Last pre-event commit: `fa202e994a77ea365061f6ac609daea1b5ad60dd`
- Domain: reliability and automated recovery for IoT gateways
- Blockchain functionality before ETHOnline: none

The repository was built in July 2026 as an MVP intended for a DoraHacks
hackathon. Its README contains a placeholder DoraHacks submission section, but
the BUIDL was never published and the project was not submitted.

Pre-existing components include health monitoring, an incident state machine,
cooldown and sliding-window recovery guards, a latch, and Telegram notification.
The ETHOnline feature will adapt selected concepts and code with attribution;
it will not represent these components as new event work.

## 2. Latch Agent

Repository: <https://github.com/Seranov67/latch-agent>

- License: MIT
- Built before ETHOnline: 4–6 August 2026
- Reused as: a design/reference source, not copied TypeScript production code

Its ActionPolicy and SPEC-002 define durable `checkAndReserve`, `finalise`,
`unfinalised`, `reconcileOnStart`, failure latching, and operator-attributed
reset semantics. The Python implementation created during ETHOnline is a new
implementation informed by those semantics. This influence is disclosed because
it is central to the safety model.

## 3. llm-log-monitor

This is a pre-existing self-hosted log analysis system. It is a reference for
operational prompting and structured LLM output. No code is vendored from it.
Any Sentinel classifier code is new event-period work.

## 4. Preparation artifacts

The planning workspace `NexGuard Sentinel` was created before hacking opened.
It contains specifications, architecture notes, configuration examples, demo
prose and throwaway learning spikes. These artifacts are pre-existing planning
material and are not presented as event-period implementation.

If any preparation document is included in the submission, its pre-event origin
remains stated in Git history/README and in this disclosure.

## 5. Event-period work

The intended new feature, implemented after hacking opens on 4 September 2026,
is the on-chain Sentinel vertical slice:

- a live The Graph Subgraph and durable event ingestion;
- Graph-derived structured AI incident classification;
- Python blockchain client and crash-safe action reservation/reconciliation;
- pause-only automated guardian with post-action state verification;
- Guardian/Vault contracts and an auditable incident reference;
- tests, CI, deployment artifacts and demo documentation.

The submission repository preserves the pre-event history and marks the final
pre-event commit with `pre-ethonline-2026`. The README links to the baseline and
summarizes the event-only diff.

## 6. Support communication

No support ticket is claimed as filed in this document. If a ticket is sent,
its date, channel and response will be recorded here after the fact.

**Ticket status:** not sent as of 3 September 2026, 21:30 Kyiv.
