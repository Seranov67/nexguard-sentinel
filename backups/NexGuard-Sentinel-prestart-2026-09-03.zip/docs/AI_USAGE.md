# AI usage

This project uses AI assistance. This log records where and how it was used so
reviewers can distinguish model assistance from human decisions and prior work.

## Tools

| Tool | Used for |
|---|---|
| Claude Code (Opus) | Pre-event architecture discussion, drafting, review and documentation |
| ChatGPT Codex | 3 September audit, current-rule research, risk analysis and preparation-document revisions |

## Working method

The human owner defines the problem, scope, safety posture and acceptance
criteria; reviews generated changes; supplies credentials; operates accounts;
executes live deployments; and makes the final product and submission decisions.

AI output is treated as a draft. Code must pass tests and live acceptance gates.
For irreversible actions, no generated recommendation bypasses deterministic
guards, access control or post-action verification.

## Activity log

| Date | File / area | AI role | Human role / required verification |
|---|---|---|---|
| Pre-event, before 03 Sep | Initial `docs/`, `templates/`, `spikes/` | Claude assisted drafting and review | Architecture direction and acceptance criteria |
| 03 Sep | `AUDIT-2026-09-03.md` | Codex inspected workspace and referenced repos, checked current official pages, produced findings and recovery plan | Requested full audit; reviews conclusions |
| 03 Sep | `README.md`, `PLAN.md`, `CHECKLIST.md`, `docs/PRIZES.md`, `docs/RULES.md`, `docs/DISCLOSURE.md`, `docs/SOS-TICKET.md`, `docs/AI_USAGE.md` | Codex revised documents to match audit and current rules | Must approve strategy and perform account-bound actions |
| 03 Sep | write-path spike | Codex corrects safety/runtime semantics and adds local tests | Must provide testnet credentials and verify live results |
| 03 Sep | The Graph spike | Codex pinned the local CLI, added a safe query client, tested the toolchain and documented unresolved dependency advisories | Must create the Studio deployment and measure live latency |
| 03 Sep | `docs/SPEC.md`, `docs/GUARDIAN-REGISTRY.md`, `docs/THREAT_MODEL.md`, demo/porting/template docs | Codex reconciled architecture, authorization, failure semantics and disclosure boundaries | Must review before the event implementation begins |

Add one row on every event day for every material code, test, documentation or
visual area touched with AI assistance. Do not pre-fill future work as completed.

## Prior work, not generated for ETHOnline

- `nexguard-edge-resilience` control loop — pre-event MIT code; see
  `DISCLOSURE.md`.
- `latch-agent` durable ActionPolicy design — pre-event reference source; see
  `DISCLOSURE.md`.
- Demo voice and screen operation remain human; no synthetic narration.
